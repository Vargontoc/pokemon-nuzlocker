package es.vargontoc.framework.ai;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.web.client.RestClient;

import tools.jackson.databind.ObjectMapper;

import es.vargontoc.framework.ai.client.AiChatBackend;
import es.vargontoc.framework.ai.client.AiChatClient;
import es.vargontoc.framework.ai.client.RestAiChatClient;
import es.vargontoc.framework.ai.client.RoutingAiChatClient;
import es.vargontoc.framework.ai.client.SpringAiChatClient;
import es.vargontoc.framework.ai.client.springai.AgentChatClientCustomizer;
import es.vargontoc.framework.ai.client.springai.AgentChatClients;
import es.vargontoc.framework.ai.client.springai.McpAgentCustomizer;
import es.vargontoc.framework.ai.client.springai.AgentVectorStoreFactory;
import es.vargontoc.framework.ai.client.springai.PdfVectorResourceLoader;
import es.vargontoc.framework.ai.client.springai.PgVectorStoreFactory;
import es.vargontoc.framework.ai.client.springai.SpringAiVectorStoreClient;
import es.vargontoc.framework.ai.client.springai.VectorStoreAgentCustomizer;
import es.vargontoc.framework.ai.client.springai.VectorStoreResolver;
import es.vargontoc.framework.ai.configuration.AgentConfigurationException;
import es.vargontoc.framework.ai.configuration.AgentProperties;
import es.vargontoc.framework.ai.configuration.AiClientType;
import es.vargontoc.framework.ai.configuration.AiProperties;
import es.vargontoc.framework.ai.domain.DefaultDomainAgent;
import es.vargontoc.framework.ai.domain.DefaultDomainAgentRegistry;
import es.vargontoc.framework.ai.domain.DomainAgentRegistry;
import es.vargontoc.framework.ai.domain.ModelVerifier;
import es.vargontoc.framework.ai.domain.PromptJson;
import es.vargontoc.framework.ai.domain.VectorResourceLoader;
import es.vargontoc.framework.ai.domain.VectorResources;
import es.vargontoc.framework.ai.domain.VectorStoreClient;
import es.vargontoc.framework.ai.ollama.OllamaModelVerifier;

/**
 * Autoconfiguración del módulo de IA.
 * <p>
 * El consumidor inyecta {@link AiChatClient}; cada agente se atiende con el
 * backend indicado en {@code type} (o {@code default-type}). Los backends REST y
 * Spring AI se registran solo si sus dependencias están en el classpath.
 */
@AutoConfiguration(afterName = "org.springframework.ai.model.chat.client.autoconfigure.ChatClientAutoConfiguration")
@EnableConfigurationProperties(AiProperties.class)
@ConditionalOnProperty(prefix = "es.vargontoc.framework.ai", name = "enabled", havingValue = "true", matchIfMissing = true)
public class AiAgentAutoConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(AiAgentAutoConfiguration.class);

    /**
     * Como {@link #springAiChatClient}: se resuelve dentro del método (no con
     * {@code @ConditionalOnBean}) porque no hay garantía de orden frente a la
     * autoconfiguración de Jackson del proyecto consumidor.
     */
    @Bean
    @ConditionalOnMissingBean
    public PromptJson promptJson(ObjectProvider<ObjectMapper> mapper) {
        ObjectMapper resolved = mapper.getIfAvailable();
        return resolved != null ? new PromptJson(resolved) : null;
    }

    @Bean
    @ConditionalOnMissingBean
    public AiChatClient aiChatClient(AiProperties properties, ObjectProvider<AiChatBackend> backends) {
        return new RoutingAiChatClient(backends.orderedStream().toList(), properties.defaultType());
    }

    @Bean
    @ConditionalOnMissingBean
    public DomainAgentRegistry domainAgentRegistry(AiProperties properties, ObjectProvider<ModelVerifier> verifier) {
        DefaultDomainAgentRegistry registry = new DefaultDomainAgentRegistry();

        if (properties.agents() != null) {
            properties.agents().forEach((domainKey, agent) -> {
                if (agent.enabled()) {
                    registerAgent(registry, properties, domainKey, agent);
                }
            });
        }

        warnIfModelsUnavailable(properties, verifier.getIfAvailable(), registry);
        return registry;
    }

    /**
     * La comprobación es específica de Ollama y solo aplica a los agentes REST.
     * Solo avisa por log: la app arranca aunque Ollama esté caído y el health
     * indicator "aiAgents" refleja el estado real.
     */
    private static void warnIfModelsUnavailable(AiProperties properties, ModelVerifier verifier,
            DomainAgentRegistry registry) {
        Map<String, String> restModels = new LinkedHashMap<>();
        registry.getAgents().stream().filter(a -> a.getClientType() == AiClientType.REST)
                .forEach(a -> restModels.put(a.getDomain(), a.getModel()));

        if (verifier == null || !properties.verifyModels() || restModels.isEmpty()) {
            return;
        }
        if (!verifier.isReachable()) {
            LOGGER.warn("Ollama no alcanzable en {}: los agentes {} no podrán responder hasta que esté disponible",
                    properties.baseUrl(), restModels.keySet());
            return;
        }
        restModels.forEach((domain, model) -> {
            if (!verifier.isModelAvailable(model)) {
                LOGGER.warn("El modelo '{}' del agente '{}' no está disponible en Ollama (ollama pull {})", model,
                        domain, model);
            }
        });
    }

    private static void registerAgent(DefaultDomainAgentRegistry registry, AiProperties properties,
            String domainKey, AgentProperties agent) {
        String modelName = agent.effectiveModel(domainKey);
        AiClientType type = agent.type() != null ? agent.type() : properties.defaultType();

        if (type != AiClientType.SPRING_AI && (agent.vectorStore() != null || agent.mcp() != null)) {
            throw new AgentConfigurationException(domainKey,
                    "vector-store y mcp solo están disponibles con type: SPRING_AI (este agente usa " + type + ")");
        }

        registry.register(new DefaultDomainAgent(domainKey, modelName, true, type));
    }

    /**
     * Backend REST (API compatible con OpenAI). Requiere spring-web.
     */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(RestClient.class)
    static class RestBackendConfiguration {

        @Bean
        @ConditionalOnMissingBean
        RestAiChatClient restAiChatClient(AiProperties properties, ObjectProvider<RestClient.Builder> builder) {
            return new RestAiChatClient(properties, builder.getIfAvailable(RestClient::builder));
        }

        @Bean
        @ConditionalOnMissingBean(ModelVerifier.class)
        ModelVerifier ollamaModelVerifier(AiProperties properties, ObjectProvider<RestClient.Builder> builder) {
            return new OllamaModelVerifier(properties, builder.getIfAvailable(RestClient::builder));
        }
    }

    /**
     * Backend Spring AI. Solo se carga si Spring AI está en el classpath y el
     * consumidor ha configurado un proveedor (que aporta el ChatClient.Builder).
     */
    @Configuration(proxyBeanMethods = false)
    @ConditionalOnClass(name = "org.springframework.ai.chat.client.ChatClient")
    static class SpringAiBackendConfiguration {

        /**
         * ChatClient propio de cada agente, construido a partir de su configuración
         * (VectorStore, MCP) y de los {@link AgentChatClientCustomizer} del contexto.
         */
        @Bean
        @ConditionalOnMissingBean
        AgentChatClients agentChatClients(AiProperties properties,
                ObjectProvider<org.springframework.ai.chat.client.ChatClient.Builder> builders,
                ObjectProvider<AgentChatClientCustomizer> customizers, ResourceLoader resourceLoader) {
            return new AgentChatClients(properties, builders, customizers.orderedStream().toList(),
                    resourceLoader.getClassLoader());
        }

        /**
         * Este backend se registra en cuanto Spring AI está en el classpath, aunque el
         * consumidor aún no tenga un proveedor configurado (igual que
         * {@code RestAiChatClient} con {@code spring-web}): {@code ChatClient.Builder}
         * solo se resuelve, y solo una vez, cuando un agente sin ChatClient propio
         * necesita el cliente por defecto.
         */
        @Bean
        @ConditionalOnMissingBean
        SpringAiChatClient springAiChatClient(
                ObjectProvider<org.springframework.ai.chat.client.ChatClient.Builder> builders,
                AgentChatClients agentChatClients) {
            return new SpringAiChatClient(() -> builders.getObject().build(), agentChatClients);
        }

        /**
         * RAG por agente. Requiere spring-ai-rag; la carga de PDF, además, spring-ai-pdf-document-reader.
         */
        @Configuration(proxyBeanMethods = false)
        @ConditionalOnClass(name = "org.springframework.ai.rag.advisor.RetrievalAugmentationAdvisor")
        static class VectorStoreCustomizerConfiguration {

            @Bean
            @ConditionalOnMissingBean
            VectorStoreResolver vectorStoreResolver(ListableBeanFactory beanFactory,
                    ObjectProvider<AgentVectorStoreFactory> storeFactory) {
                return new VectorStoreResolver(beanFactory, storeFactory);
            }

            @Bean
            @ConditionalOnMissingBean
            VectorStoreClient vectorStoreClient(AiProperties properties, VectorStoreResolver resolver) {
                return new SpringAiVectorStoreClient(properties, resolver);
            }

            /**
             * Store propio por agente en PostgreSQL (vector-store.pg). Requiere spring-ai-pgvector-store.
             */
            @Configuration(proxyBeanMethods = false)
            @ConditionalOnClass(name = "org.springframework.ai.vectorstore.pgvector.PgVectorStore")
            static class PgVectorStoreConfiguration {

                @Bean
                @ConditionalOnMissingBean
                AgentVectorStoreFactory pgVectorStoreFactory(
                        ObjectProvider<org.springframework.jdbc.core.JdbcTemplate> jdbcTemplate,
                        ObjectProvider<org.springframework.ai.embedding.EmbeddingModel> embeddingModel) {
                    return new PgVectorStoreFactory(jdbcTemplate, embeddingModel);
                }
            }

            @Bean
            @ConditionalOnMissingBean
            VectorStoreAgentCustomizer vectorStoreAgentCustomizer(VectorStoreResolver resolver,
                    ObjectProvider<VectorResources> resources, ObjectProvider<VectorResourceLoader> loader) {
                return new VectorStoreAgentCustomizer(resolver, resources, loader);
            }

            /**
             * Un VectorResources de un agente que no existe o no es SPRING_AI se ignoraría en silencio
             * (p. ej. por un error al escribir el dominio): mejor fallar al arrancar.
             */
            @Bean
            static SmartInitializingSingleton vectorResourcesValidator(AiProperties properties,
                    ObjectProvider<VectorResources> resources) {
                return () -> resources.stream().forEach(r -> {
                    AgentProperties agent = properties.agents() != null ? properties.agents().get(r.domain()) : null;
                    AiClientType type = agent != null && agent.type() != null ? agent.type()
                            : properties.defaultType();
                    if (agent == null || !agent.enabled() || type != AiClientType.SPRING_AI) {
                        throw new AgentConfigurationException(r.domain(), "hay un VectorResources para este agente, "
                                + "pero no está definido y habilitado con type: SPRING_AI");
                    }
                });
            }

            @Configuration(proxyBeanMethods = false)
            @ConditionalOnClass(name = "org.springframework.ai.reader.pdf.PagePdfDocumentReader")
            static class PdfLoaderConfiguration {

                @Bean
                @ConditionalOnMissingBean
                VectorResourceLoader vectorResourceLoader(AiProperties properties, VectorStoreResolver resolver) {
                    return new PdfVectorResourceLoader(properties, resolver);
                }
            }
        }

        /**
         * Tools MCP por agente. Requiere spring-ai-mcp (incluido en spring-ai-starter-mcp-client).
         */
        @Configuration(proxyBeanMethods = false)
        @ConditionalOnClass(name = "org.springframework.ai.mcp.SyncMcpToolCallbackProvider")
        static class McpCustomizerConfiguration {

            @Bean
            @ConditionalOnMissingBean
            McpAgentCustomizer mcpAgentCustomizer(
                    ObjectProvider<java.util.List<io.modelcontextprotocol.client.McpSyncClient>> clients,
                    ObjectProvider<org.springframework.ai.mcp.McpToolFilter> toolFilter,
                    ObjectProvider<org.springframework.ai.mcp.McpToolNamePrefixGenerator> prefixGenerator,
                    ObjectProvider<org.springframework.ai.mcp.ToolContextToMcpMetaConverter> metaConverter) {
                return new McpAgentCustomizer(clients, toolFilter, prefixGenerator, metaConverter);
            }
        }
    }
}
