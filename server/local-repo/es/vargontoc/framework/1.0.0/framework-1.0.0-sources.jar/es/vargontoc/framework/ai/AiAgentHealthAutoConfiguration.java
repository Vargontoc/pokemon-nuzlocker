package es.vargontoc.framework.ai;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.health.autoconfigure.contributor.ConditionalOnEnabledHealthIndicator;
import org.springframework.boot.health.contributor.HealthIndicator;
import org.springframework.context.annotation.Bean;

import es.vargontoc.framework.ai.domain.DomainAgentRegistry;
import es.vargontoc.framework.ai.domain.ModelVerifier;
import es.vargontoc.framework.ai.ollama.AiAgentsHealthIndicator;

/**
 * Health indicator (Actuator) de los modelos de los agentes REST.
 * Va en su propia autoconfiguración, ordenada tras {@link AiAgentAutoConfiguration},
 * para que {@code @ConditionalOnBean} vea ya el registro de agentes.
 * Se desactiva con {@code management.health.aiAgents.enabled=false}.
 */
@AutoConfiguration(after = AiAgentAutoConfiguration.class)
@ConditionalOnClass(HealthIndicator.class)
@ConditionalOnEnabledHealthIndicator("aiAgents")
public class AiAgentHealthAutoConfiguration {

    @Bean
    @ConditionalOnBean({ ModelVerifier.class, DomainAgentRegistry.class })
    @ConditionalOnMissingBean(name = "aiAgentsHealthIndicator")
    AiAgentsHealthIndicator aiAgentsHealthIndicator(ModelVerifier verifier, DomainAgentRegistry registry) {
        return new AiAgentsHealthIndicator(verifier, registry);
    }
}
