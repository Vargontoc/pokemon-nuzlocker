package es.vargontoc.framework.ai.client;

import java.util.List;
import java.util.concurrent.Flow;

import org.springframework.ai.chat.client.ChatClient;

import es.vargontoc.framework.ai.configuration.AiClientType;
import es.vargontoc.framework.ai.domain.DomainAgent;
import es.vargontoc.framework.ai.model.ChatCompletionResponse;
import es.vargontoc.framework.ai.model.ChatMessage;
import es.vargontoc.framework.ai.model.ChatOptions;

/**
 * Implementación concreta de un cliente de chat (REST, Spring AI...).
 * <p>
 * No extiende {@link AiChatClient} a propósito: los consumidores inyectan
 * siempre {@link AiChatClient}, que enruta hacia el backend adecuado.
 */
public interface AiChatBackend {

    /**
     * Tipo de cliente que implementa este backend
     *
     * @return tipo de cliente
     */
    AiClientType type();

    /**
     * @see AiChatClient#chat(DomainAgent, List, ChatOptions)
     */
    ChatCompletionResponse chat(DomainAgent agent, List<ChatMessage> messages, ChatOptions options);

    /**
     * @see AiChatClient#stream(DomainAgent, List, ChatOptions)
     */
    Flow.Publisher<String> stream(DomainAgent agent, List<ChatMessage> messages, ChatOptions options);
}
