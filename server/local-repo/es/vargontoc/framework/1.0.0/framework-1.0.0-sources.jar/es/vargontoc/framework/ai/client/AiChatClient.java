package es.vargontoc.framework.ai.client;

import java.util.List;
import java.util.concurrent.Flow;

import es.vargontoc.framework.ai.domain.DomainAgent;
import es.vargontoc.framework.ai.model.ChatCompletionResponse;
import es.vargontoc.framework.ai.model.ChatMessage;
import es.vargontoc.framework.ai.model.ChatOptions;

/**
 * Cliente de chat para la API de IA.
 * <p>
 * Es la única abstracción que debe inyectar un proyecto consumidor: el backend
 * concreto (REST o Spring AI) se decide por agente en la configuración.
 */
public interface AiChatClient {

    /**
     * Realiza un chat con el agente
     *
     * @param agent    agente de IA
     * @param messages mensajes de chat
     * @param options  opciones de la petición
     * @return respuesta del agente
     */
    ChatCompletionResponse chat(DomainAgent agent, List<ChatMessage> messages, ChatOptions options);

    /**
     * Realiza un chat con el agente recibiendo la respuesta en streaming.
     * El publisher es frío: la petición se lanza al suscribirse.
     *
     * @param agent    agente de IA
     * @param messages mensajes de chat
     * @param options  opciones de la petición
     * @return publisher con los fragmentos de texto de la respuesta
     */
    Flow.Publisher<String> stream(DomainAgent agent, List<ChatMessage> messages, ChatOptions options);

    /**
     * Realiza un chat con el agente
     *
     * @param agent  agente de IA
     * @param prompt prompt a enviar
     * @return respuesta del agente
     */
    default String chat(DomainAgent agent, String prompt) {
        return chat(agent, List.of(ChatMessage.user(prompt))).contentOrEmpty();
    }

    /**
     * Realiza un chat con el agente
     *
     * @param agent    agente de IA
     * @param messages mensajes de chat
     * @return respuesta del agente
     */
    default ChatCompletionResponse chat(DomainAgent agent, List<ChatMessage> messages) {
        return chat(agent, messages, ChatOptions.defaults());
    }

    /**
     * Realiza un chat con el agente y convierte la respuesta JSON al tipo indicado
     *
     * @param agent        agente de IA
     * @param prompt       prompt a enviar
     * @param responseType tipo de respuesta
     * @return respuesta del agente
     */
    default <T> T chat(DomainAgent agent, String prompt, Class<T> responseType) {
        return StructuredResponseParser.parse(chat(agent, prompt), responseType);
    }

    /**
     * Realiza un chat en streaming con un único prompt
     *
     * @param agent  agente de IA
     * @param prompt prompt a enviar
     * @return publisher con los fragmentos de texto de la respuesta
     */
    default Flow.Publisher<String> stream(DomainAgent agent, String prompt) {
        return stream(agent, List.of(ChatMessage.user(prompt)), ChatOptions.defaults());
    }
}
