package es.vargontoc.framework.ai.client;

/**
 * La respuesta del modelo no se pudo convertir al tipo solicitado
 */
public class AiResponseParseException extends RuntimeException {

    private final String rawResponse;

    public AiResponseParseException(String rawResponse, Class<?> targetType, Throwable cause) {
        super("No se pudo convertir la respuesta del modelo a " + targetType.getName(), cause);
        this.rawResponse = rawResponse;
    }

    /**
     * Respuesta original del modelo
     *
     * @return respuesta cruda
     */
    public String getRawResponse() {
        return rawResponse;
    }
}
