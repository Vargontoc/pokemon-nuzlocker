package es.vargontoc.framework.ai.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.Flow;
import java.util.concurrent.SubmissionPublisher;
import java.util.function.Supplier;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

import es.vargontoc.framework.ai.configuration.AiClientType;
import es.vargontoc.framework.ai.configuration.AiProperties;
import es.vargontoc.framework.ai.domain.DomainAgent;
import es.vargontoc.framework.ai.model.ChatCompletionChunk;
import es.vargontoc.framework.ai.model.ChatCompletionRequest;
import es.vargontoc.framework.ai.model.ChatCompletionResponse;
import es.vargontoc.framework.ai.model.ChatMessage;
import es.vargontoc.framework.ai.model.ChatOptions;
import tools.jackson.databind.json.JsonMapper;

/**
 * Backend REST para cualquier API compatible con OpenAI
 * ({@code POST {base-url}/chat/completions}): Ollama, OpenAI, vLLM, etc.
 */
public class RestAiChatClient implements AiChatBackend {

    private static final String COMPLETIONS_PATH = "/chat/completions";
    private static final String SSE_DATA_PREFIX = "data:";
    private static final String SSE_DONE = "[DONE]";
    private static final long BACKOFF_MILLIS = 200;

    private final RestClient client;
    private final JsonMapper mapper = JsonMapper.builder().build();
    private final int retries;

    public RestAiChatClient(AiProperties properties) {
        this(properties, RestClient.builder());
    }

    public RestAiChatClient(AiProperties properties, RestClient.Builder builder) {
        Duration timeout = Duration.ofMillis(properties.timeout());
        JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory(
                HttpClient.newBuilder().connectTimeout(timeout).build());
        factory.setReadTimeout(timeout);

        RestClient.Builder configured = builder.clone()
                .baseUrl(properties.baseUrl())
                .requestFactory(factory);
        if (properties.apiKey() != null && !properties.apiKey().isBlank()) {
            configured.defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + properties.apiKey());
        }
        this.client = configured.build();
        this.retries = Math.max(0, properties.retries());
    }

    @Override
    public AiClientType type() {
        return AiClientType.REST;
    }

    @Override
    public ChatCompletionResponse chat(DomainAgent agent, List<ChatMessage> messages, ChatOptions options) {
        ChatCompletionRequest request = request(agent, messages, options, false);
        return withRetries(() -> client.post().uri(COMPLETIONS_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .body(request)
                .retrieve()
                .body(ChatCompletionResponse.class));
    }

    @Override
    public Flow.Publisher<String> stream(DomainAgent agent, List<ChatMessage> messages, ChatOptions options) {
        ChatCompletionRequest request = request(agent, messages, options, true);

        // Publisher frío: la petición se lanza al suscribirse (SubmissionPublisher descarta
        // los ítems emitidos sin suscriptores). No se reintenta: ya podría haber emitido texto.
        return subscriber -> {
            SubmissionPublisher<String> publisher = new SubmissionPublisher<>();
            publisher.subscribe(subscriber);
            Thread.ofVirtual().name("ai-rest-stream").start(() -> readStream(request, publisher));
        };
    }

    private void readStream(ChatCompletionRequest request, SubmissionPublisher<String> publisher) {
        try {
            client.post().uri(COMPLETIONS_PATH)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.TEXT_EVENT_STREAM, MediaType.APPLICATION_JSON)
                    .body(request)
                    .exchange((req, res) -> {
                        if (res.getStatusCode().isError()) {
                            throw new IllegalStateException("La API de IA respondió " + res.getStatusCode());
                        }
                        try (BufferedReader reader = new BufferedReader(
                                new InputStreamReader(res.getBody(), StandardCharsets.UTF_8))) {
                            String line;
                            while ((line = reader.readLine()) != null && publisher.getNumberOfSubscribers() > 0) {
                                if (!line.startsWith(SSE_DATA_PREFIX)) {
                                    continue;
                                }
                                String data = line.substring(SSE_DATA_PREFIX.length()).strip();
                                if (SSE_DONE.equals(data)) {
                                    break;
                                }
                                String content = mapper.readValue(data, ChatCompletionChunk.class).contentOrEmpty();
                                if (!content.isEmpty()) {
                                    publisher.submit(content);
                                }
                            }
                        }
                        return null;
                    });
            publisher.close();
        } catch (Exception e) {
            publisher.closeExceptionally(e);
        }
    }

    private ChatCompletionRequest request(DomainAgent agent, List<ChatMessage> messages, ChatOptions options,
            boolean stream) {
        ChatOptions effective = options != null ? options : ChatOptions.defaults();
        return new ChatCompletionRequest(agent.getModel(), messages, effective.temperature(), stream,
                effective.maxTokens());
    }

    /**
     * Reintenta solo ante fallos transitorios: sin conexión/timeout o errores 5xx
     */
    private <T> T withRetries(Supplier<T> call) {
        for (int attempt = 0;; attempt++) {
            try {
                return call.get();
            } catch (ResourceAccessException | HttpServerErrorException e) {
                if (attempt >= retries) {
                    throw e;
                }
                try {
                    Thread.sleep(BACKOFF_MILLIS * (attempt + 1));
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw e;
                }
            }
        }
    }
}
