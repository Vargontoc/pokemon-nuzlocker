package es.vargontoc.framework.ai.client;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Flow;

import es.vargontoc.framework.ai.configuration.AiClientType;
import es.vargontoc.framework.ai.domain.DomainAgent;
import es.vargontoc.framework.ai.model.ChatCompletionResponse;
import es.vargontoc.framework.ai.model.ChatMessage;
import es.vargontoc.framework.ai.model.ChatOptions;

/**
 * Cliente que delega en el backend configurado para cada agente
 * (o en el tipo por defecto si el agente no indica ninguno).
 */
public class RoutingAiChatClient implements AiChatClient {

    private final Map<AiClientType, AiChatBackend> backends = new EnumMap<>(AiClientType.class);
    private final AiClientType defaultType;

    public RoutingAiChatClient(List<AiChatBackend> backends, AiClientType defaultType) {
        backends.forEach(b -> this.backends.put(b.type(), b));
        this.defaultType = defaultType;
    }

    @Override
    public ChatCompletionResponse chat(DomainAgent agent, List<ChatMessage> messages, ChatOptions options) {
        return backendFor(agent).chat(agent, messages, options);
    }

    @Override
    public Flow.Publisher<String> stream(DomainAgent agent, List<ChatMessage> messages, ChatOptions options) {
        return backendFor(agent).stream(agent, messages, options);
    }

    private AiChatBackend backendFor(DomainAgent agent) {
        AiClientType type = agent.getClientType() != null ? agent.getClientType() : defaultType;
        AiChatBackend backend = backends.get(type);
        if (backend == null) {
            throw new IllegalStateException("El agente '" + agent.getDomain() + "' usa el cliente " + type
                    + " pero no está disponible. " + hint(type));
        }
        return backend;
    }

    private static String hint(AiClientType type) {
        return switch (type) {
            case SPRING_AI -> "Añade un starter de Spring AI (con un ChatClient.Builder) al proyecto.";
            case REST -> "Añade spring-web al classpath del proyecto.";
        };
    }
}
