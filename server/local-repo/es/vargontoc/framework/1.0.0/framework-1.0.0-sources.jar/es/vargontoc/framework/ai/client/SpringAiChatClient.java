package es.vargontoc.framework.ai.client;

import java.util.List;
import java.util.concurrent.Flow;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.metadata.ChatResponseMetadata;
import org.springframework.ai.chat.metadata.Usage;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;

import es.vargontoc.framework.ai.client.springai.AgentChatClients;
import es.vargontoc.framework.ai.configuration.AiClientType;
import es.vargontoc.framework.ai.domain.DomainAgent;
import es.vargontoc.framework.ai.model.ChatCompletionResponse;
import es.vargontoc.framework.ai.model.ChatMessage;
import es.vargontoc.framework.ai.model.ChatOptions;
import reactor.adapter.JdkFlowAdapter;

/**
 * Backend sobre el {@link ChatClient} de Spring AI: el proveedor lo decide el
 * starter de Spring AI que incluya el proyecto consumidor.
 * <p>
 * Cada agente usa su propio {@link ChatClient} (con sus advisors y tools) si se
 * construyó a partir de su configuración; si no, el {@link ChatClient} compartido.
 */
public class SpringAiChatClient implements AiChatBackend {

    private final java.util.function.Supplier<ChatClient> defaultClient;
    private final AgentChatClients agentClients;

    public SpringAiChatClient(ChatClient chatClient) {
        this(chatClient, null);
    }

    public SpringAiChatClient(ChatClient defaultClient, AgentChatClients agentClients) {
        this(() -> defaultClient, agentClients);
    }

    /**
     * @param defaultClient se resuelve solo la primera vez que hace falta (un agente
     *                       SPRING_AI sin ChatClient propio): permite registrar este
     *                       backend aunque el proyecto aún no tenga un proveedor
     *                       configurado, sin fallar mientras no se use
     */
    public SpringAiChatClient(java.util.function.Supplier<ChatClient> defaultClient, AgentChatClients agentClients) {
        this.defaultClient = memoize(defaultClient);
        this.agentClients = agentClients;
    }

    private static java.util.function.Supplier<ChatClient> memoize(java.util.function.Supplier<ChatClient> supplier) {
        java.util.concurrent.atomic.AtomicReference<ChatClient> cached = new java.util.concurrent.atomic.AtomicReference<>();
        return () -> cached.updateAndGet(value -> value != null ? value : supplier.get());
    }

    @Override
    public AiClientType type() {
        return AiClientType.SPRING_AI;
    }

    @Override
    public ChatCompletionResponse chat(DomainAgent agent, List<ChatMessage> messages, ChatOptions options) {
        ChatResponse response = clientFor(agent).prompt()
                .messages(toSpringAi(messages))
                .options(toSpringAi(agent, options))
                .call()
                .chatResponse();
        return toCompletion(agent, response);
    }

    @Override
    public Flow.Publisher<String> stream(DomainAgent agent, List<ChatMessage> messages, ChatOptions options) {
        return JdkFlowAdapter.publisherToFlowPublisher(clientFor(agent).prompt()
                .messages(toSpringAi(messages))
                .options(toSpringAi(agent, options))
                .stream()
                .content());
    }

    private ChatClient clientFor(DomainAgent agent) {
        if (agentClients == null) {
            return defaultClient.get();
        }
        return agentClients.find(agent.getDomain()).orElseGet(defaultClient);
    }

    private static List<Message> toSpringAi(List<ChatMessage> messages) {
        return messages.stream().map(SpringAiChatClient::toSpringAi).toList();
    }

    private static Message toSpringAi(ChatMessage message) {
        return switch (message.role()) {
            case "system" -> new SystemMessage(message.content());
            case "user" -> new UserMessage(message.content());
            case "assistant" -> new AssistantMessage(message.content());
            default -> throw new IllegalArgumentException("Rol de mensaje no soportado: " + message.role());
        };
    }

    private static org.springframework.ai.chat.prompt.ChatOptions.Builder<?> toSpringAi(DomainAgent agent,
            ChatOptions options) {
        ChatOptions effective = options != null ? options : ChatOptions.defaults();
        return org.springframework.ai.chat.prompt.ChatOptions.builder()
                .model(agent.getModel())
                .temperature(effective.temperature())
                .maxTokens(effective.maxTokens());
    }

    private static ChatCompletionResponse toCompletion(DomainAgent agent, ChatResponse response) {
        if (response == null || response.getResult() == null) {
            return new ChatCompletionResponse(null, agent.getModel(), List.of(), null);
        }
        Generation generation = response.getResult();
        String text = generation.getOutput() != null ? generation.getOutput().getText() : null;
        String finishReason = generation.getMetadata() != null ? generation.getMetadata().getFinishReason() : null;

        ChatResponseMetadata metadata = response.getMetadata();
        String model = metadata != null && metadata.getModel() != null && !metadata.getModel().isBlank()
                ? metadata.getModel()
                : agent.getModel();
        Usage usage = metadata != null ? metadata.getUsage() : null;

        return new ChatCompletionResponse(
                metadata != null ? metadata.getId() : null,
                model,
                List.of(new ChatCompletionResponse.Choice(
                        new ChatCompletionResponse.Choice.Message("assistant", text), finishReason, 0)),
                usage != null
                        ? new ChatCompletionResponse.Usage(usage.getPromptTokens(), usage.getCompletionTokens(),
                                usage.getTotalTokens())
                        : null);
    }
}
