package es.vargontoc.framework.ai.client;

import tools.jackson.databind.json.JsonMapper;

/**
 * Convierte la respuesta textual de un modelo a un tipo Java.
 * Tolera que el modelo envuelva el JSON en un bloque de código markdown.
 */
public final class StructuredResponseParser {

    private static final JsonMapper MAPPER = JsonMapper.builder().build();

    private StructuredResponseParser() {
    }

    /**
     * Parsea la respuesta del modelo
     *
     * @param response     respuesta textual del modelo
     * @param responseType tipo esperado
     * @return objeto parseado
     * @throws AiResponseParseException si la respuesta no es un JSON válido para el tipo
     */
    public static <T> T parse(String response, Class<T> responseType) {
        try {
            return MAPPER.readValue(stripCodeFence(response), responseType);
        } catch (Exception e) {
            throw new AiResponseParseException(response, responseType, e);
        }
    }

    private static String stripCodeFence(String response) {
        String text = response == null ? "" : response.strip();
        if (text.startsWith("```")) {
            int firstLineEnd = text.indexOf('\n');
            int lastFence = text.lastIndexOf("```");
            if (firstLineEnd > 0 && lastFence > firstLineEnd) {
                return text.substring(firstLineEnd + 1, lastFence).strip();
            }
        }
        return text;
    }
}
