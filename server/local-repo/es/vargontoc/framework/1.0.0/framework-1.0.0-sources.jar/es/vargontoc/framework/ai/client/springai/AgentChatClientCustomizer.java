package es.vargontoc.framework.ai.client.springai;

import org.springframework.ai.chat.client.ChatClient;

import es.vargontoc.framework.ai.configuration.AgentProperties;

/**
 * Personaliza el {@link ChatClient.Builder} de un agente Spring AI antes de
 * construir su {@link ChatClient}.
 * <p>
 * El framework aporta implementaciones para VectorStore y MCP a partir de la
 * configuración del agente. Un proyecto consumidor puede registrar sus propios
 * beans de este tipo para casos que la configuración no cubra: se aplican
 * después de los del framework, a cada agente {@code SPRING_AI} habilitado
 * (decide con {@code domain} sobre cuáles actuar).
 */
@FunctionalInterface
public interface AgentChatClientCustomizer {

    /**
     * @param domain  clave del agente
     * @param agent   configuración del agente
     * @param builder builder propio de este agente
     */
    void customize(String domain, AgentProperties agent, ChatClient.Builder builder);
}
