package es.vargontoc.framework.ai.client.springai;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.ai.chat.client.advisor.ToolCallingAdvisor;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.util.ClassUtils;

import es.vargontoc.framework.ai.configuration.AgentConfigurationException;
import es.vargontoc.framework.ai.configuration.AgentProperties;
import es.vargontoc.framework.ai.configuration.AiClientType;
import es.vargontoc.framework.ai.configuration.AiProperties;

/**
 * {@link ChatClient} propio de cada agente {@code SPRING_AI}, construido en el
 * arranque a partir de su configuración (VectorStore, MCP) y de los
 * {@link AgentChatClientCustomizer} registrados. Falla pronto si la
 * configuración de algún agente no es válida.
 */
public class AgentChatClients {

    static final String RETRIEVAL_ADVISOR = "org.springframework.ai.rag.advisor.RetrievalAugmentationAdvisor";
    static final String MCP_TOOL_PROVIDER = "org.springframework.ai.mcp.SyncMcpToolCallbackProvider";

    private final Map<String, ChatClient> clients = new HashMap<>();

    /**
     * @param properties  configuración del módulo
     * @param builders    proveedor de {@link ChatClient.Builder} (prototype: cada
     *                    agente recibe uno nuevo)
     * @param customizers personalizadores, ya ordenados
     * @param classLoader classloader con el que comprobar las dependencias opcionales
     */
    public AgentChatClients(AiProperties properties, ObjectProvider<ChatClient.Builder> builders,
            List<AgentChatClientCustomizer> customizers, ClassLoader classLoader) {
        if (properties.agents() == null) {
            return;
        }
        properties.agents().forEach((domain, agent) -> {
            if (agent.enabled() && effectiveType(properties, agent) == AiClientType.SPRING_AI) {
                requireDependencies(domain, agent, classLoader);
                ChatClient.Builder builder = builders.getIfAvailable();
                if (builder == null) {
                    throw new AgentConfigurationException(domain, "es SPRING_AI pero no hay ningún "
                            + "ChatClient.Builder en el contexto: añade el starter de tu proveedor "
                            + "(Ollama, OpenAI, Anthropic...)");
                }
                // Sin esto, un ChatClient obtenido con find() (p. ej. para necesidades
                // específicas, sin pasar por AiChatClient) llamaría al modelo por
                // defecto del proveedor en vez del configurado para este agente
                builder.defaultAdvisors(List.of(
                    new SimpleLoggerAdvisor()));
                builder.defaultOptions(
                    org.springframework.ai.chat.prompt.ChatOptions.builder().model(agent.effectiveModel(domain)));
                    customizers.forEach(c -> c.customize(domain, agent, builder));
                clients.put(domain, builder.build());
            }
        });
    }

    /**
     * ChatClient del agente
     *
     * @param domain clave del agente
     * @return su ChatClient, o vacío si el agente no se configuró por propiedades
     */
    public Optional<ChatClient> find(String domain) {
        return Optional.ofNullable(clients.get(domain));
    }

    private static AiClientType effectiveType(AiProperties properties, AgentProperties agent) {
        return agent.type() != null ? agent.type() : properties.defaultType();
    }

    private static void requireDependencies(String domain, AgentProperties agent, ClassLoader classLoader) {
        if (agent.vectorStore() != null && !ClassUtils.isPresent(RETRIEVAL_ADVISOR, classLoader)) {
            throw new AgentConfigurationException(domain,
                    "usa vector-store pero falta la dependencia org.springframework.ai:spring-ai-rag");
        }
        if (agent.mcp() != null && !ClassUtils.isPresent(MCP_TOOL_PROVIDER, classLoader)) {
            throw new AgentConfigurationException(domain,
                    "usa mcp pero falta la dependencia org.springframework.ai:spring-ai-mcp "
                            + "(incluida en spring-ai-starter-mcp-client)");
        }
    }
}
