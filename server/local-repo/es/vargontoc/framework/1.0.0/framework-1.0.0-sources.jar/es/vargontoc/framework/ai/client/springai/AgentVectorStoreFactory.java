package es.vargontoc.framework.ai.client.springai;

import org.springframework.ai.vectorstore.VectorStore;

import es.vargontoc.framework.ai.configuration.AgentProperties.PgProperties;

/**
 * Crea el VectorStore propio de un agente a partir de su configuración
 * ({@code vector-store.pg}). Es una interfaz sin tipos de pgvector para que el
 * resto del módulo no dependa de él, que es una dependencia opcional.
 */
public interface AgentVectorStoreFactory {

    /**
     * @param domain clave del agente
     * @param pg     configuración de PostgreSQL del agente
     * @return el store, ya inicializado (tabla e índice creados)
     */
    VectorStore create(String domain, PgProperties pg);
}
