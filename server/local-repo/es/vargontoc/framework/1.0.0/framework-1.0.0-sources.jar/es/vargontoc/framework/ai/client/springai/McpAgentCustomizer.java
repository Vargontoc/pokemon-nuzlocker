package es.vargontoc.framework.ai.client.springai;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.mcp.McpToolFilter;
import org.springframework.ai.mcp.McpToolNamePrefixGenerator;
import org.springframework.ai.mcp.SyncMcpToolCallbackProvider;
import org.springframework.ai.mcp.ToolContextToMcpMetaConverter;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.core.Ordered;

import es.vargontoc.framework.ai.configuration.AgentConfigurationException;
import es.vargontoc.framework.ai.configuration.AgentProperties;
import es.vargontoc.framework.ai.configuration.AgentProperties.McpProperties;
import io.modelcontextprotocol.client.McpSyncClient;

/**
 * Tools MCP por agente: da al agente solo las tools de las conexiones
 * indicadas en {@code mcp.connections}.
 * <p>
 * Spring AI crea todos los clientes MCP en una única lista y un único
 * provider con todas sus tools; aquí se filtran por conexión para que cada
 * agente vea únicamente las suyas.
 */
public class McpAgentCustomizer implements AgentChatClientCustomizer, Ordered {

    /** Spring AI nombra cada cliente "{spring.ai.mcp.client.name} - {conexión}" */
    private static final String NAME_SEPARATOR = " - ";

    private final ObjectProvider<List<McpSyncClient>> clients;
    private final ObjectProvider<McpToolFilter> toolFilter;
    private final ObjectProvider<McpToolNamePrefixGenerator> prefixGenerator;
    private final ObjectProvider<ToolContextToMcpMetaConverter> metaConverter;

    public McpAgentCustomizer(ObjectProvider<List<McpSyncClient>> clients, ObjectProvider<McpToolFilter> toolFilter,
            ObjectProvider<McpToolNamePrefixGenerator> prefixGenerator,
            ObjectProvider<ToolContextToMcpMetaConverter> metaConverter) {
        this.clients = clients;
        this.toolFilter = toolFilter;
        this.prefixGenerator = prefixGenerator;
        this.metaConverter = metaConverter;
    }

    @Override
    public void customize(String domain, AgentProperties agent, ChatClient.Builder builder) {
        McpProperties config = agent.mcp();
        if (config == null) {
            return;
        }
        if (config.connections() == null || config.connections().isEmpty()) {
            throw new AgentConfigurationException(domain, "mcp.connections no puede estar vacío");
        }

        List<McpSyncClient> available = clients.getIfAvailable(List::of);
        List<McpSyncClient> selected = new ArrayList<>();
        for (String connection : config.connections()) {
            selected.add(find(domain, connection, available));
        }

        SyncMcpToolCallbackProvider.Builder provider = SyncMcpToolCallbackProvider.builder().mcpClients(selected);
        // Mismos beans de personalización que usa el provider global de Spring AI
        toolFilter.ifAvailable(provider::toolFilter);
        prefixGenerator.ifAvailable(provider::toolNamePrefixGenerator);
        metaConverter.ifAvailable(provider::toolContextToMcpMetaConverter);

        // defaultTools acepta ToolCallbackProvider; defaultToolCallbacks está deprecado desde Spring AI 2.0
        builder.defaultTools(provider.build());
    }

    private static McpSyncClient find(String domain, String connection, List<McpSyncClient> available) {
        return available.stream().filter(c -> matches(c, connection)).findFirst()
                .orElseThrow(() -> new AgentConfigurationException(domain,
                        "no existe la conexión MCP '" + connection + "'. Clientes MCP disponibles: "
                                + available.stream().map(c -> c.getClientInfo().name()).toList()
                                + (available.isEmpty()
                                        ? " (¿falta spring-ai-starter-mcp-client o usas type=ASYNC?)"
                                        : "")));
    }

    private static boolean matches(McpSyncClient client, String connection) {
        String name = client.getClientInfo().name();
        return name.equals(connection) || name.endsWith(NAME_SEPARATOR + connection);
    }

    @Override
    public int getOrder() {
        return 0;
    }
}
