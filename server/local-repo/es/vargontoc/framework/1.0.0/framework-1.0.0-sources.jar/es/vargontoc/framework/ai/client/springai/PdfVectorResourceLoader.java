package es.vargontoc.framework.ai.client.springai;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.pdf.PagePdfDocumentReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.Filter;
import org.springframework.ai.vectorstore.filter.FilterExpressionBuilder;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;

import es.vargontoc.framework.ai.configuration.AgentConfigurationException;
import es.vargontoc.framework.ai.configuration.AgentProperties;
import es.vargontoc.framework.ai.configuration.AiProperties;
import es.vargontoc.framework.ai.domain.VectorResourceLoader;

/**
 * Carga PDF en el VectorStore de un agente: un documento por página, troceado por
 * tokens. Cada fragmento guarda en sus metadatos el nombre del fichero
 * ({@value #SOURCE}) y el hash de su contenido ({@value #SOURCE_HASH}), con lo que
 * un documento ya cargado no se vuelve a procesar (ni se pagan de nuevo sus
 * embeddings) y uno modificado sustituye al anterior.
 * <p>
 * Requiere un VectorStore con soporte de filtros por metadatos.
 */
public class PdfVectorResourceLoader implements VectorResourceLoader {

    static final String SOURCE = "source";
    static final String SOURCE_HASH = "sourceHash";

    private static final Logger LOGGER = LoggerFactory.getLogger(PdfVectorResourceLoader.class);

    private final AiProperties properties;
    private final VectorStoreResolver resolver;

    public PdfVectorResourceLoader(AiProperties properties, VectorStoreResolver resolver) {
        this.properties = properties;
        this.resolver = resolver;
    }

    @Override
    public int load(String domain, Resource document) {
        AgentProperties agent = properties.agents() != null ? properties.agents().get(domain) : null;
        if (agent == null || agent.vectorStore() == null) {
            throw new AgentConfigurationException(domain,
                    "no declara vector-store, así que no hay dónde cargar '" + document.getDescription() + "'");
        }
        return ingest(resolver.resolve(domain, agent.vectorStore()), document);
    }

    int ingest(VectorStore store, Resource document) {
        byte[] content = read(document);
        String source = sourceName(document);
        String hash = sha256(content);

        // Se lee de memoria: un Resource de un solo uso (InputStreamResource) no se puede releer
        List<Document> pages = new PagePdfDocumentReader(new ByteArrayResource(content, source)).get();
        List<Document> chunks = TokenTextSplitter.builder().build().apply(pages).stream()
                .map(chunk -> chunk.mutate().metadata(SOURCE, source).metadata(SOURCE_HASH, hash).build())
                .toList();
        if (chunks.isEmpty()) {
            LOGGER.warn("El documento '{}' no contiene texto extraíble (¿es un PDF escaneado?); no se carga", source);
            return 0;
        }

        if (isLoaded(store, chunks.get(0).getText(), source, hash)) {
            LOGGER.info("El documento '{}' ya está cargado en el VectorStore; se omite", source);
            return 0;
        }
        removeOldVersion(store, source);

        store.add(chunks);
        LOGGER.info("Documento '{}' cargado en el VectorStore: {} fragmentos", source, chunks.size());
        return chunks.size();
    }

    /**
     * Comprueba si el documento ya está en el store buscando, con el filtro de nombre y hash, el texto de
     * su primer fragmento. Se busca ese texto (y no uno cualquiera) porque los stores aplican el umbral de
     * similitud de forma estricta: PgVectorStore descarta lo que no supere la distancia, incluso con el
     * umbral en 0, así que una consulta sin relación con el contenido no encontraría nada. El texto del
     * propio fragmento es prácticamente idéntico al guardado y siempre lo encuentra.
     */
    private static boolean isLoaded(VectorStore store, String firstChunkText, String source, String hash) {
        FilterExpressionBuilder b = new FilterExpressionBuilder();
        Filter.Expression sameDocument = b.and(b.eq(SOURCE, source), b.eq(SOURCE_HASH, hash)).build();
        return !store.similaritySearch(SearchRequest.builder().query(firstChunkText).topK(1)
                .similarityThresholdAll().filterExpression(sameDocument).build()).isEmpty();
    }

    private static void removeOldVersion(VectorStore store, String source) {
        try {
            store.delete(new FilterExpressionBuilder().eq(SOURCE, source).build());
        } catch (UnsupportedOperationException e) {
            LOGGER.warn("El VectorStore no permite borrar por filtro: si '{}' ya existía, quedarán fragmentos "
                    + "de la versión anterior", source);
        }
    }

    private static byte[] read(Resource document) {
        try {
            return document.getContentAsByteArray();
        } catch (IOException e) {
            throw new IllegalArgumentException("No se pudo leer el documento " + document.getDescription(), e);
        }
    }

    private static String sourceName(Resource document) {
        String filename = document.getFilename();
        return filename != null ? filename : document.getDescription();
    }

    private static String sha256(byte[] content) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(content));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
