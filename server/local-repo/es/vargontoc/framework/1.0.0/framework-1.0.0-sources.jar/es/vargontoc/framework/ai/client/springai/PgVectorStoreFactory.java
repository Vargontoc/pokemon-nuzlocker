package es.vargontoc.framework.ai.client.springai;

import java.util.Locale;
import java.util.regex.Pattern;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.pgvector.PgVectorStore;
import org.springframework.ai.vectorstore.pgvector.PgVectorStore.PgDistanceType;
import org.springframework.ai.vectorstore.pgvector.PgVectorStore.PgIdType;
import org.springframework.ai.vectorstore.pgvector.PgVectorStore.PgIndexType;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.jdbc.core.JdbcTemplate;

import es.vargontoc.framework.ai.configuration.AgentConfigurationException;
import es.vargontoc.framework.ai.configuration.AgentProperties.PgProperties;
import es.vargontoc.framework.ai.configuration.VectorDistance;
import es.vargontoc.framework.ai.configuration.VectorIndex;

/**
 * Crea un {@link PgVectorStore} por agente, con su propia tabla, sobre el
 * {@link JdbcTemplate} y el {@link EmbeddingModel} del contexto.
 * <p>
 * Los ids son de tipo texto (no UUID) para admitir ids propios en los documentos
 * que se añadan a mano.
 */
public class PgVectorStoreFactory implements AgentVectorStoreFactory {

    /** El nombre de la tabla se incorpora a sentencias DDL: solo se admiten identificadores simples */
    private static final Pattern IDENTIFIER = Pattern.compile("[a-zA-Z_][a-zA-Z0-9_]{0,62}");
    private static final String DEFAULT_TABLE_PREFIX = "vector_store_";
    /** Límite de pgvector para indexar (HNSW e IVFFlat) columnas vector */
    private static final int MAX_INDEXED_DIMENSIONS = 2000;

    private final ObjectProvider<JdbcTemplate> jdbcTemplate;
    private final ObjectProvider<EmbeddingModel> embeddingModel;

    public PgVectorStoreFactory(ObjectProvider<JdbcTemplate> jdbcTemplate,
            ObjectProvider<EmbeddingModel> embeddingModel) {
        this.jdbcTemplate = jdbcTemplate;
        this.embeddingModel = embeddingModel;
    }

    @Override
    public VectorStore create(String domain, PgProperties pg) {
        JdbcTemplate jdbc = jdbcTemplate.getIfAvailable();
        if (jdbc == null) {
            throw new AgentConfigurationException(domain, "vector-store.pg necesita un JdbcTemplate: añade "
                    + "spring-boot-starter-jdbc, el driver de PostgreSQL y configura spring.datasource.*");
        }
        EmbeddingModel embeddings = embeddingModel.getIfAvailable();
        if (embeddings == null) {
            throw new AgentConfigurationException(domain,
                    "vector-store.pg necesita un EmbeddingModel: añade el starter de tu proveedor de embeddings");
        }

        String table = tableName(domain, pg);
        int dimensions = pg.dimensions() != null ? pg.dimensions() : embeddings.dimensions();
        VectorIndex index = pg.index() != null ? pg.index() : VectorIndex.HNSW;
        VectorDistance distance = pg.distance() != null ? pg.distance() : VectorDistance.COSINE;
        validate(domain, dimensions, index);

        PgVectorStore store = PgVectorStore.builder(jdbc, embeddings)
                .vectorTableName(table)
                .dimensions(dimensions)
                .distanceType(distance(distance))
                .indexType(index(index))
                .idType(PgIdType.TEXT)
                .initializeSchema(true)
                .build();
        try {
            // Fuera del contenedor de Spring nadie invoca el ciclo de vida: crea extensión, tabla e índice
            store.afterPropertiesSet();
        } catch (RuntimeException e) {
            throw new AgentConfigurationException(domain, "no se pudo inicializar la tabla '" + table + "' en "
                    + "PostgreSQL (¿la base de datos tiene la extensión pgvector? con la imagen "
                    + "pgvector/pgvector viene instalada): " + e.getMessage());
        }
        return store;
    }

    private static String tableName(String domain, PgProperties pg) {
        String table = pg.tableName() != null && !pg.tableName().isBlank() ? pg.tableName()
                : DEFAULT_TABLE_PREFIX + domain.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", "_");
        if (!IDENTIFIER.matcher(table).matches()) {
            throw new AgentConfigurationException(domain, "el nombre de tabla '" + table + "' no es válido: solo "
                    + "letras, números y _, sin empezar por número, de hasta 63 caracteres"
                    + (pg.tableName() == null ? " (indica vector-store.pg.table-name)" : ""));
        }
        return table;
    }

    private static void validate(String domain, int dimensions, VectorIndex index) {
        if (dimensions <= 0) {
            throw new AgentConfigurationException(domain, "vector-store.pg.dimensions debe ser mayor que 0");
        }
        if (index != VectorIndex.NONE && dimensions > MAX_INDEXED_DIMENSIONS) {
            throw new AgentConfigurationException(domain, "pgvector no indexa más de " + MAX_INDEXED_DIMENSIONS
                    + " dimensiones y el modelo usa " + dimensions
                    + ": pon vector-store.pg.index: NONE o usa un modelo con menos dimensiones");
        }
    }

    private static PgDistanceType distance(VectorDistance distance) {
        return switch (distance) {
            case COSINE -> PgDistanceType.COSINE_DISTANCE;
            case EUCLIDEAN -> PgDistanceType.EUCLIDEAN_DISTANCE;
            case INNER_PRODUCT -> PgDistanceType.NEGATIVE_INNER_PRODUCT;
        };
    }

    private static PgIndexType index(VectorIndex index) {
        return switch (index) {
            case NONE -> PgIndexType.NONE;
            case IVFFLAT -> PgIndexType.IVFFLAT;
            case HNSW -> PgIndexType.HNSW;
        };
    }
}
