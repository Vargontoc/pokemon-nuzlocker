package es.vargontoc.framework.ai.client.springai;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.FilterExpressionBuilder;

import es.vargontoc.framework.ai.configuration.AgentProperties;
import es.vargontoc.framework.ai.configuration.AiProperties;
import es.vargontoc.framework.ai.domain.VectorStoreClient;
import es.vargontoc.framework.ai.model.CreateDocumentForVector;
import es.vargontoc.framework.ai.model.VectorFilter;
import es.vargontoc.framework.ai.model.VectorHit;
import es.vargontoc.framework.ai.model.VectorQuery;

/**
 * {@link VectorStoreClient} sobre el VectorStore que {@link VectorStoreResolver}
 * localiza para cada agente.
 */
public class SpringAiVectorStoreClient implements VectorStoreClient {

    private final AiProperties properties;
    private final VectorStoreResolver resolver;

    public SpringAiVectorStoreClient(AiProperties properties, VectorStoreResolver resolver) {
        this.properties = properties;
        this.resolver = resolver;
    }

    @Override
    public List<VectorHit> search(String agent, VectorQuery query) {
        AgentProperties.VectorStoreProperties config = config(agent);
        VectorStore store = resolver.resolve(agent, config);

        SearchRequest.Builder request = SearchRequest.builder().query(query.text());
        Integer topK = query.topK() != null ? query.topK() : config.topK();
        if (topK != null) {
            request.topK(topK);
        }
        Double threshold = query.similarityThreshold() != null ? query.similarityThreshold()
                : config.similarityThreshold();
        if (threshold != null) {
            request.similarityThreshold(threshold);
        }
        if (query.filter() != null && !query.filter().isEmpty()) {
            request.filterExpression(expression(query.filter()));
        }

        List<Document> documents = Objects.requireNonNullElse(store.similaritySearch(request.build()), List.of());
        return documents.stream()
                .map(d -> new VectorHit(d.getId(), d.getText(), d.getMetadata(), d.getScore()))
                .toList();
    }

    @Override
    public void add(String agent, List<CreateDocumentForVector> documents) {
        VectorStore store = resolver.resolve(agent, config(agent));
        store.add(documents.stream().map(d -> new Document(d.id(), d.content(), d.metadata())).toList());
    }

    @Override
    public void deleteByMetadata(String agent, VectorFilter filter) {
        if (filter == null || filter.isEmpty()) {
            throw new IllegalArgumentException("El filtro de borrado no puede estar vacío");
        }
        VectorStore store = resolver.resolve(agent, config(agent));
        store.delete(expression(filter));
    }

    private AgentProperties.VectorStoreProperties config(String agent) {
        Map<String, AgentProperties> agents = properties.agents() != null ? properties.agents() : Map.of();
        AgentProperties found = agents.get(agent);
        if (found == null || !found.enabled() || found.vectorStore() == null) {
            throw new IllegalArgumentException("El agente '" + agent + "' no existe, no está habilitado o no declara "
                    + "vector-store. Con vector-store: " + agents.entrySet().stream()
                            .filter(e -> e.getValue().enabled() && e.getValue().vectorStore() != null)
                            .map(Map.Entry::getKey).collect(Collectors.toList()));
        }
        return found.vectorStore();
    }

    private static org.springframework.ai.vectorstore.filter.Filter.Expression expression(VectorFilter filter) {
        FilterExpressionBuilder b = new FilterExpressionBuilder();
        FilterExpressionBuilder.Op result = null;
        for (VectorFilter.Condition c : filter.conditions()) {
            FilterExpressionBuilder.Op op = switch (c.operator()) {
                case EQ -> b.eq(c.key(), c.value());
                case NE -> b.ne(c.key(), c.value());
                case GT -> b.gt(c.key(), c.value());
                case GTE -> b.gte(c.key(), c.value());
                case LT -> b.lt(c.key(), c.value());
                case LTE -> b.lte(c.key(), c.value());
            };
            result = result == null ? op : b.and(result, op);
        }
        return result.build();
    }
}
