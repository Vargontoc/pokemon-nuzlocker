package es.vargontoc.framework.ai.client.springai;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.rag.advisor.RetrievalAugmentationAdvisor;
import org.springframework.ai.rag.generation.augmentation.ContextualQueryAugmenter;
import org.springframework.ai.rag.retrieval.search.VectorStoreDocumentRetriever;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.core.Ordered;
import org.springframework.core.io.Resource;

import es.vargontoc.framework.ai.configuration.AgentConfigurationException;
import es.vargontoc.framework.ai.configuration.AgentProperties;
import es.vargontoc.framework.ai.configuration.AgentProperties.VectorStoreProperties;
import es.vargontoc.framework.ai.domain.VectorResourceLoader;
import es.vargontoc.framework.ai.domain.VectorResources;

/**
 * RAG por agente: añade un {@link RetrievalAugmentationAdvisor} sobre el VectorStore
 * indicado en {@code vector-store}. Si el proyecto declara un {@link VectorResources}
 * para el agente, carga sus documentos en el store (los ya cargados se omiten) y usa
 * sus plantillas de prompt.
 */
public class VectorStoreAgentCustomizer implements AgentChatClientCustomizer, Ordered {

    private final VectorStoreResolver resolver;
    private final ObjectProvider<VectorResources> resources;
    private final ObjectProvider<VectorResourceLoader> loader;

    public VectorStoreAgentCustomizer(VectorStoreResolver resolver, ObjectProvider<VectorResources> resources,
            ObjectProvider<VectorResourceLoader> loader) {
        this.resolver = resolver;
        this.resources = resources;
        this.loader = loader;
    }

    @Override
    public void customize(String domain, AgentProperties agent, ChatClient.Builder builder) {
        VectorResources own = resourcesOf(domain);
        VectorStoreProperties config = agent.vectorStore();

        if (config == null) {
            if (own != null) {
                throw new AgentConfigurationException(domain, "hay un VectorResources para este agente pero no "
                        + "declara vector-store en la configuración (indica al menos vector-store.bean)");
            }
            return;
        }

        VectorStore store = resolver.resolve(domain, config);
        if (own != null) {
            loadDocuments(domain, own);
        }
        builder.defaultAdvisors(advisor(domain, store, config, own));
    }

    private VectorResources resourcesOf(String domain) {
        List<VectorResources> found = resources.stream().filter(r -> r.domain().equals(domain)).toList();
        if (found.size() > 1) {
            throw new AgentConfigurationException(domain, "hay " + found.size() + " VectorResources para el mismo "
                    + "agente; declara solo uno (puede llevar varios documentos)");
        }
        return found.isEmpty() ? null : found.get(0);
    }

    private void loadDocuments(String domain, VectorResources own) {
        if (own.documents().isEmpty()) {
            return;
        }
        VectorResourceLoader documentLoader = loader.getIfAvailable();
        if (documentLoader == null) {
            throw new AgentConfigurationException(domain, "declara documentos pero falta la dependencia "
                    + "org.springframework.ai:spring-ai-pdf-document-reader");
        }
        own.documents().forEach(document -> documentLoader.load(domain, document));
    }

    private static RetrievalAugmentationAdvisor advisor(String domain, VectorStore store,
            VectorStoreProperties config, VectorResources own) {
        VectorStoreDocumentRetriever.Builder retriever = VectorStoreDocumentRetriever.builder().vectorStore(store);
        if (config.topK() != null) {
            if (config.topK() <= 0) {
                throw new AgentConfigurationException(domain, "vector-store.top-k debe ser mayor que 0");
            }
            retriever.topK(config.topK());
        }
        if (config.similarityThreshold() != null) {
            double threshold = config.similarityThreshold();
            if (threshold < 0.0 || threshold > 1.0) {
                throw new AgentConfigurationException(domain,
                        "vector-store.similarity-threshold debe estar entre 0.0 y 1.0");
            }
            retriever.similarityThreshold(threshold);
        }

        return RetrievalAugmentationAdvisor.builder()
                .documentRetriever(retriever.build())
                .queryAugmenter(augmenter(domain, own))
                .build();
    }

    private static ContextualQueryAugmenter augmenter(String domain, VectorResources own) {
        ContextualQueryAugmenter.Builder augmenter = ContextualQueryAugmenter.builder();
        Resource context = own != null ? own.contextTemplate() : null;
        Resource empty = own != null ? own.emptyContextTemplate() : null;

        if (context != null) {
            augmenter.promptTemplate(template(domain, context));
        }
        if (empty != null) {
            augmenter.emptyContextPromptTemplate(template(domain, empty));
        }
        // Sin plantilla de contexto vacío, sin resultados la pregunta pasa tal cual; con ella se usa esa plantilla
        augmenter.allowEmptyContext(empty == null);

        try {
            return augmenter.build();
        } catch (IllegalArgumentException e) {
            throw new AgentConfigurationException(domain, "plantilla de contexto no válida: " + e.getMessage()
                    + " (la plantilla de contexto debe usar las variables {query} y {context})");
        }
    }

    private static PromptTemplate template(String domain, Resource resource) {
        try {
            return new PromptTemplate(resource.getContentAsString(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new AgentConfigurationException(domain,
                    "no se pudo leer la plantilla " + resource.getDescription() + ": " + e.getMessage());
        }
    }

    @Override
    public int getOrder() {
        return 0;
    }
}
