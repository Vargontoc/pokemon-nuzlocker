package es.vargontoc.framework.ai.client.springai;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.FilterExpressionBuilder;
import org.springframework.beans.factory.ListableBeanFactory;
import org.springframework.beans.factory.ObjectProvider;

import es.vargontoc.framework.ai.configuration.AgentConfigurationException;
import es.vargontoc.framework.ai.configuration.AgentProperties.VectorStoreProperties;
import es.vargontoc.framework.ai.model.CreateDocumentForVector;

/**
 * Localiza el VectorStore de un agente: el bean indicado en {@code vector-store.bean}
 * o, con {@code vector-store.pg}, un store propio en PostgreSQL que se crea la primera
 * vez y se reutiliza.
 */
public class VectorStoreResolver {

    private final ListableBeanFactory beanFactory;
    private final ObjectProvider<AgentVectorStoreFactory> storeFactory;
    /** Stores creados por el framework (vector-store.pg), por clave de agente */
    private final Map<String, VectorStore> agentStores = new ConcurrentHashMap<>();

    public VectorStoreResolver(ListableBeanFactory beanFactory) {
        this(beanFactory, null);
    }

    public VectorStoreResolver(ListableBeanFactory beanFactory, ObjectProvider<AgentVectorStoreFactory> storeFactory) {
        this.beanFactory = beanFactory;
        this.storeFactory = storeFactory;
    }

    /**
     * @param domain clave del agente
     * @param config configuración de vector-store del agente
     * @return el VectorStore indicado, el que el framework crea con {@code pg}, o el
     *         único que haya en el contexto
     * @throws AgentConfigurationException si no existe o hay varios sin indicar cuál
     */
    public VectorStore resolve(String domain, VectorStoreProperties config) {
        boolean hasBean = config.bean() != null && !config.bean().isBlank();

        if (config.pg() != null) {
            if (hasBean) {
                throw new AgentConfigurationException(domain,
                        "vector-store.bean y vector-store.pg son excluyentes: usa un bean existente o deja que "
                                + "el framework cree el store en PostgreSQL");
            }
            return agentStores.computeIfAbsent(domain, key -> createPgStore(key, config));
        }

        Map<String, VectorStore> stores = beanFactory.getBeansOfType(VectorStore.class);

        if (hasBean) {
            VectorStore store = stores.get(config.bean());
            if (store == null) {
                throw new AgentConfigurationException(domain, "no existe ningún bean VectorStore llamado '"
                        + config.bean() + "'. Disponibles: " + stores.keySet());
            }
            return store;
        }
        if (stores.isEmpty()) {
            throw new AgentConfigurationException(domain,
                    "usa vector-store pero no hay ningún bean VectorStore. Añade el starter de tu vector store.");
        }
        if (stores.size() > 1) {
            throw new AgentConfigurationException(domain, "hay varios VectorStore " + stores.keySet()
                    + "; indica cuál con vector-store.bean");
        }
        return stores.values().iterator().next();
    }

    private VectorStore createPgStore(String domain, VectorStoreProperties config) {
        AgentVectorStoreFactory factory = storeFactory != null ? storeFactory.getIfAvailable() : null;
        if (factory == null) {
            throw new AgentConfigurationException(domain, "usa vector-store.pg pero falta la dependencia "
                    + "org.springframework.ai:spring-ai-pgvector-store");
        }
        return factory.create(domain, config.pg());
    }

    /**
     * Borra los documentos cuyo metadato {@code key} vale {@code value}
     *
     * @param vector bean VectorStore o clave de un agente con {@code vector-store.pg}
     * @param key    metadato
     * @param value  valor
     * @throws IllegalArgumentException si no existe ese store
     */
    public void reindexEqVector(String vector, String key, String value) {
        find(vector).delete(new FilterExpressionBuilder().eq(key, value).build());
    }

    /**
     * Añade documentos a un store
     *
     * @param vector    bean VectorStore o clave de un agente con {@code vector-store.pg}
     * @param documents documentos a añadir
     * @throws IllegalArgumentException si no existe ese store
     */
    public void addDocument(String vector, List<CreateDocumentForVector> documents) {
        var docs = documents.stream().map(m -> new Document(m.id(), m.content(), m.metadata())).toList();
        find(vector).add(docs);
    }

    private VectorStore find(String vector) {
        Map<String, VectorStore> beans = beanFactory.getBeansOfType(VectorStore.class);
        VectorStore store = beans.containsKey(vector) ? beans.get(vector) : agentStores.get(vector);
        if (store == null) {
            Set<String> available = new HashSet<>(beans.keySet());
            available.addAll(agentStores.keySet());
            throw new IllegalArgumentException(
                    "No existe el VectorStore '" + vector + "'. Disponibles: " + available);
        }
        return store;
    }
}
