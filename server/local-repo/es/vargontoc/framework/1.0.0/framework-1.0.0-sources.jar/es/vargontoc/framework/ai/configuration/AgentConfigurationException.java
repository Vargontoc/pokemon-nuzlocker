package es.vargontoc.framework.ai.configuration;

/**
 * Configuración inválida de un agente (recurso inexistente, dependencia ausente...).
 * Se lanza en el arranque para fallar pronto con un mensaje accionable.
 */
public class AgentConfigurationException extends IllegalStateException {

    public AgentConfigurationException(String domain, String message) {
        super("Agente de IA '" + domain + "': " + message);
    }
}
