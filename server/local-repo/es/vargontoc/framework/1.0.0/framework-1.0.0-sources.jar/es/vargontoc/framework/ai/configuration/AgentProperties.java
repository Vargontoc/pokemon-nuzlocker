package es.vargontoc.framework.ai.configuration;

import java.util.List;

import org.springframework.boot.context.properties.bind.DefaultValue;


/**
 * Configuración del agente de IA
 *
 * @param name        nombre del agente
 * @param model       modelo de IA a utilizar; si está vacío se usa la clave del agente
 * @param type        tipo de cliente de IA; si no se indica se usa {@code default-type}
 * @param enabled     activa o desactiva el agente
 * @param vectorStore RAG: el agente consulta un VectorStore antes de responder.
 *                    Solo con {@code type: SPRING_AI}
 * @param mcp         tools de servidores MCP externos a las que tiene acceso el
 *                    agente. Solo con {@code type: SPRING_AI}
 */
public record AgentProperties(
                String name,
                String model,
                AiClientType type,
                @DefaultValue("false") boolean enabled,
                VectorStoreProperties vectorStore,
                McpProperties mcp) {

    /**
     * @param domainKey clave del agente
     * @return {@link #model()}, o {@code domainKey} si no se indicó
     */
    public String effectiveModel(String domainKey) {
        return model != null && !model.isBlank() ? model : domainKey;
    }

    /**
     * Acceso del agente a un VectorStore (RAG).
     * Para activarlo hay que indicar al menos una propiedad.
     *
     * @param bean                nombre del bean VectorStore; si se omite se usa el
     *                            único VectorStore del contexto. Excluyente con
     *                            {@code pg}
     * @param topK                número máximo de documentos recuperados
     * @param similarityThreshold umbral de similitud (0.0 - 1.0)
     * @param pg                  el framework crea para este agente un store propio
     *                            en PostgreSQL con pgvector, en lugar de usar un bean
     *                            existente. Excluyente con {@code bean}
     */
    public record VectorStoreProperties(String bean, Integer topK, Double similarityThreshold, PgProperties pg) {
    }

    /**
     * Store propio del agente en PostgreSQL con pgvector. Requiere en el proyecto
     * {@code spring-ai-pgvector-store}, un {@code JdbcTemplate} (DataSource
     * configurado), el driver de PostgreSQL y un {@code EmbeddingModel}; la base de
     * datos debe tener la extensión {@code vector} (por ejemplo, la imagen
     * {@code pgvector/pgvector}). La tabla se crea si no existe; una tabla existente
     * no se modifica.
     *
     * @param tableName  tabla del agente; por defecto {@code vector_store_<agente>}.
     *                   Solo letras, números y {@code _}
     * @param dimensions dimensiones de los embeddings; por defecto las del
     *                   {@code EmbeddingModel}
     * @param distance   distancia de comparación; por defecto {@code COSINE}
     * @param index      índice; por defecto {@code HNSW}. Con {@code HNSW} o
     *                   {@code IVFFLAT} pgvector admite hasta 2000 dimensiones
     */
    public record PgProperties(
            String tableName,
            Integer dimensions,
            @DefaultValue("COSINE") VectorDistance distance,
            @DefaultValue("HNSW") VectorIndex index) {
    }

     /*
        @code spring.ai.mcp.client.*} cuyas tools puede usar el agente
     */
    public record McpProperties(List<String> connections) {
    }
}
