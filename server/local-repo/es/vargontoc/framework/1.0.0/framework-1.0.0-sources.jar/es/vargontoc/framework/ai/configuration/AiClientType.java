package es.vargontoc.framework.ai.configuration;

/**
 * Tipos de cliente de IA
 * 
 */
public enum AiClientType {
    REST,
    SPRING_AI
}
