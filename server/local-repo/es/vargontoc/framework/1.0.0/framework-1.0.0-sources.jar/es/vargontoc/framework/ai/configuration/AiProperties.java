package es.vargontoc.framework.ai.configuration;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Configuración de la API de IA
 *
 * @param enabled      activa o desactiva todo el módulo de IA
 * @param baseUrl      URL base de la API REST compatible con OpenAI, incluido el
 *                     sufijo /v1 (solo cliente REST)
 * @param timeout      timeout en milisegundos (solo cliente REST)
 * @param retries      reintentos ante errores de conexión o 5xx (solo cliente REST)
 * @param apiKey       API key enviada como Bearer; vacía para no enviar cabecera
 *                     (solo cliente REST)
 * @param defaultType  cliente que atiende a los agentes que no indican
 *                     {@code type}
 * @param verifyModels comprueba en el arranque que los modelos de los agentes
 *                     REST existen en Ollama (GET /api/tags). Desactívalo si el
 *                     endpoint REST no es Ollama
 * @param agents       mapa de agentes de IA
 */
@ConfigurationProperties(prefix = "es.vargontoc.framework.ai")
public record AiProperties(
                @DefaultValue("true") boolean enabled,
                @DefaultValue("http://localhost:11434/v1") String baseUrl,
                @DefaultValue("60000") int timeout,
                @DefaultValue("3") int retries,
                @DefaultValue("") String apiKey,
                @DefaultValue("REST") AiClientType defaultType,
                @DefaultValue("true") boolean verifyModels,
                Map<String, AgentProperties> agents) {
}
