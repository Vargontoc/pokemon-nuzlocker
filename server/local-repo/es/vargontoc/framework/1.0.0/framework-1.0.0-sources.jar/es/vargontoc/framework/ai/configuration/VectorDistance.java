package es.vargontoc.framework.ai.configuration;

/**
 * Función de distancia con la que un vector store compara embeddings
 */
public enum VectorDistance {
    COSINE,
    EUCLIDEAN,
    INNER_PRODUCT
}
