package es.vargontoc.framework.ai.configuration;

/**
 * Tipo de índice de un vector store
 */
public enum VectorIndex {
    NONE,
    IVFFLAT,
    HNSW
}
