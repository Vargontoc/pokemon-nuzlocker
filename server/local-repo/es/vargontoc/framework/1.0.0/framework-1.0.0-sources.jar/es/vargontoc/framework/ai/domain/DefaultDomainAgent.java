package es.vargontoc.framework.ai.domain;

import es.vargontoc.framework.ai.configuration.AiClientType;

public record DefaultDomainAgent(
        String domain,
        String model,
        boolean enabled,
        AiClientType clientType) implements DomainAgent {

    public DefaultDomainAgent(String domain, String model, boolean enabled) {
        this(domain, model, enabled, null);
    }

    @Override
    public String getDomain() {
        return domain;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public boolean isEnabled() {
        return enabled;
    }

    @Override
    public AiClientType getClientType() {
        return clientType;
    }
}
