package es.vargontoc.framework.ai.domain;

import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registro por defecto de agentes de IA
 */
public class DefaultDomainAgentRegistry implements DomainAgentRegistry {

    private final ConcurrentHashMap<String, DomainAgent> agents = new ConcurrentHashMap<>();

    @Override
    public void register(DomainAgent agent) {
        if (agent == null || agent.getDomain() == null || agent.getDomain().isBlank()) {
            throw new IllegalArgumentException("El agente no puede ser nulo ni tener un dominio nulo o vacío");
        }
        agents.put(agent.getDomain(), agent);
    }

    @Override
    public Optional<DomainAgent> getAgent(String domain) {
        if (domain == null || domain.isBlank()) {
            throw new IllegalArgumentException("El dominio no puede ser nulo o vacío");
        }
        return Optional.ofNullable(agents.get(domain));
    }

    @Override
    public Collection<DomainAgent> getAgents() {
        return agents.values();
    }

    @Override
    public boolean hasAgent(String domain) {
        return agents.containsKey(domain);
    }
}
