package es.vargontoc.framework.ai.domain;

import es.vargontoc.framework.ai.configuration.AiClientType;

/**
 * Interface para los agentes de IA
 */
public interface DomainAgent {
    /**
     * Obtiene el dominio del agente
     *
     * @return dominio del agente
     */
    String getDomain();

    /**
     * Obtiene el modelo de IA a utilizar
     *
     * @return modelo de IA a utilizar
     */
    String getModel();

    /**
     * Indica si el agente está habilitado
     *
     * @return true si el agente está habilitado, false en caso contrario
     */
    boolean isEnabled();

    /**
     * Obtiene el tipo de cliente (backend) que atiende a este agente
     *
     * @return tipo de cliente, o null para usar el tipo por defecto de la configuración
     */
    default AiClientType getClientType() {
        return null;
    }
}
