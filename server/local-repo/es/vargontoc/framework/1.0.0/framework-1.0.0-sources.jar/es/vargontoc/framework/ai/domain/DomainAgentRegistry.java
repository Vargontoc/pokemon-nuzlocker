package es.vargontoc.framework.ai.domain;

import java.util.Collection;
import java.util.Optional;

import es.vargontoc.framework.exception.AgentNotFoundException;

/**
 * Interface para el registro de agentes de IA
 * 
 */
public interface DomainAgentRegistry {

    /**
     * Registra un agente de IA
     * 
     * @param agent agente de IA a registrar
     */
    void register(DomainAgent agent);

    /**
     * Obtiene un agente de IA por dominio
     * 
     * @param domain dominio del agente de IA
     * @return agente de IA
     */
    Optional<DomainAgent> getAgent(String domain);

    /**
     * Obtiene un agente de IA por dominio, fallando si no existe
     *
     * @param domain dominio del agente de IA
     * @return agente de IA
     * @throws AgentNotFoundException si no hay ningún agente con ese dominio
     */
    default DomainAgent requireAgent(String domain) {
        return getAgent(domain).orElseThrow(() -> new AgentNotFoundException(domain,
                getAgents().stream().map(d -> d.getDomain()).sorted().toList()));
    }

    /**
     * Obtiene todos los agentes de IA
     * 
     * @return colección de agentes de IA
     */
    Collection<DomainAgent> getAgents();

    boolean hasAgent(String domain);
}
