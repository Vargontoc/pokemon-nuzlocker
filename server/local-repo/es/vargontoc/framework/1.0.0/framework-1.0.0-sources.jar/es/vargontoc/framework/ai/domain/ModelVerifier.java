package es.vargontoc.framework.ai.domain;

/**
 * Comprueba que el proveedor de modelos responde y que los modelos de los agentes existen
 */
public interface ModelVerifier {

    /**
     * Comprueba si el proveedor de modelos responde
     * 
     * @return true si responde, false en caso contrario
     */
    boolean isReachable();

    /**
     * Comprueba si el modelo está disponible
     * 
     * @param modelName nombre del modelo
     * @return true si el modelo está disponible, false en caso contrario
     */
    boolean isModelAvailable(String modelName);
}
