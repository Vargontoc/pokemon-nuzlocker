package es.vargontoc.framework.ai.domain;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;

/**
 * Serializa valores a JSON para incluirlos en un prompt (p. ej. herramientas o
 * ejemplos con formato). Usa el {@code ObjectMapper} de Jackson 3 que trae Spring Boot
 * 4 por defecto.
 */
public class PromptJson {

    private final ObjectMapper mapper;

    public PromptJson(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    public String write(Object value) {
        try {
            return mapper.writeValueAsString(value);
        } catch (JacksonException e) {
            throw new IllegalStateException("No se pudo serializar para el prompt", e);
        }
    }
}
