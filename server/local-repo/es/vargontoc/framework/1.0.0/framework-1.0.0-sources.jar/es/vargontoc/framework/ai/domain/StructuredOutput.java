package es.vargontoc.framework.ai.domain;

import java.util.regex.Pattern;

import org.springframework.ai.converter.BeanOutputConverter;

import es.vargontoc.framework.exception.AgentOutputException;

/**
 * Extrae el JSON de la respuesta de un modelo local. Tolera bloques <think>, vallas ```json y texto antes o después del objeto
 * StructuredOutput
 */
public final class StructuredOutput {
    
    private static final Pattern THINK_BLOCK = Pattern.compile("(?s)<think>.*?</think>");

    private StructuredOutput(){}

    public static <T> T parse(String raw, BeanOutputConverter<T> converter) throws AgentOutputException  {
        String cleaned = THINK_BLOCK.matcher(raw == null ? "" : raw).replaceAll("").trim();
        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        if(start < 0 || end < start)
            throw new AgentOutputException(raw, "La respuesta no contiene un objeto JSON", null);
        
        try {
            return converter.convert(cleaned.substring(start, end + 1));
        }catch(RuntimeException e){
            throw new AgentOutputException(raw, "JSON inválido: " + e.getMessage(), e);
        }
    
    }

}
