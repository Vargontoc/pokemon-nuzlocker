package es.vargontoc.framework.ai.domain;

import org.springframework.core.io.Resource;

/**
 * Carga documentos en el VectorStore de un agente para que este pueda usarlos como
 * contexto (RAG). Sirve para cargas en caliente, por ejemplo un PDF subido por un
 * endpoint; los documentos que el agente necesita desde el arranque se declaran con
 * {@link VectorResources}.
 * <p>
 * Requiere {@code org.springframework.ai:spring-ai-pdf-document-reader}. El agente
 * debe declarar {@code vector-store} en su configuración.
 */
public interface VectorResourceLoader {

    /**
     * Trocea el PDF y lo guarda en el VectorStore del agente. Si ese mismo documento
     * (mismo nombre y mismo contenido) ya está cargado no hace nada; si el nombre
     * coincide pero el contenido cambió, sustituye la versión anterior.
     * <p>
     * Es una operación bloqueante: calcula los embeddings de todo el documento.
     *
     * @param domain   clave del agente
     * @param document PDF a cargar
     * @return número de fragmentos guardados; 0 si el documento ya estaba cargado
     */
    int load(String domain, Resource document);
}
