package es.vargontoc.framework.ai.domain;

import java.util.List;

import org.springframework.core.io.Resource;

/**
 * Recursos de contexto (RAG) de un agente: los documentos que se cargan en su
 * VectorStore al arrancar y las plantillas del prompt. Se declara como bean; el
 * agente debe tener {@code vector-store} en su configuración (que aporta el store,
 * el {@code top-k} y el umbral de similitud).
 * <p>
 * La plantilla de contexto usa las variables {@code {query}} (la pregunta) y
 * {@code {context}} (los fragmentos recuperados). La de contexto vacío se usa cuando
 * no se recupera nada: <b>no admite variables</b> y sustituye a la pregunta del
 * usuario, así que debe ser una instrucción para el modelo (por ejemplo, "responde
 * que no tienes información sobre eso"). Si se omite la de contexto vacío, sin
 * resultados la pregunta pasa sin modificar; si se omite la de contexto se usa la de
 * Spring AI.
 *
 * @param domain               clave del agente
 * @param documents            PDF a cargar (los ya cargados se omiten)
 * @param contextTemplate      plantilla cuando hay contexto, o null
 * @param emptyContextTemplate instrucción cuando no hay contexto (sin variables), o null
 */
public record VectorResources(String domain, List<Resource> documents, Resource contextTemplate,
        Resource emptyContextTemplate) {

    public VectorResources {
        if (domain == null || domain.isBlank()) {
            throw new IllegalArgumentException("El dominio del agente no puede ser nulo ni vacío");
        }
        documents = documents == null ? List.of() : List.copyOf(documents);
    }

    /**
     * Un documento y las dos plantillas
     *
     * @param domain               clave del agente
     * @param document             PDF a cargar
     * @param contextTemplate      plantilla cuando hay contexto, o null
     * @param emptyContextTemplate instrucción cuando no hay contexto (sin variables), o null
     * @return los recursos del agente
     */
    public static VectorResources of(String domain, Resource document, Resource contextTemplate,
            Resource emptyContextTemplate) {
        return new VectorResources(domain, List.of(document), contextTemplate, emptyContextTemplate);
    }

    /**
     * Un documento con las plantillas por defecto
     *
     * @param domain   clave del agente
     * @param document PDF a cargar
     * @return los recursos del agente
     */
    public static VectorResources of(String domain, Resource document) {
        return of(domain, document, null, null);
    }
}
