package es.vargontoc.framework.ai.domain;

import java.util.List;

import es.vargontoc.framework.ai.model.CreateDocumentForVector;
import es.vargontoc.framework.ai.model.VectorFilter;
import es.vargontoc.framework.ai.model.VectorHit;
import es.vargontoc.framework.ai.model.VectorQuery;

/**
 * Acceso al VectorStore de un agente con tipos del framework: el consumidor no
 * necesita Spring AI en su classpath. Funciona igual con {@code vector-store.bean}
 * que con {@code vector-store.pg}.
 * <p>
 * Solo está disponible con {@code type: SPRING_AI}; el agente debe estar habilitado y
 * declarar {@code vector-store}. Las operaciones son bloqueantes (calculan embeddings).
 */
public interface VectorStoreClient {

    /**
     * @param agent clave del agente
     * @param query consulta; sus valores nulos toman los del {@code vector-store} del agente
     * @return los documentos más parecidos que cumplen el filtro, del más al menos parecido
     * @throws IllegalArgumentException si el agente no existe o no tiene vector-store
     */
    List<VectorHit> search(String agent, VectorQuery query);

    /**
     * Añade documentos al store del agente (si un id ya existe, se sustituye)
     *
     * @throws IllegalArgumentException si el agente no existe o no tiene vector-store
     */
    void add(String agent, List<CreateDocumentForVector> documents);

    /**
     * Borra los documentos cuyo metadato {@code key} vale {@code value}
     *
     * @throws IllegalArgumentException si el agente no existe o no tiene vector-store
     */
    default void deleteByMetadata(String agent, String key, String value) {
        deleteByMetadata(agent, VectorFilter.where().eq(key, value));
    }

    /**
     * Borra los documentos que cumplen el filtro (varias condiciones combinadas con AND)
     *
     * @throws IllegalArgumentException si el agente no existe o no tiene vector-store
     */
    void deleteByMetadata(String agent, VectorFilter filter);
}
