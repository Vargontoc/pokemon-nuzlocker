package es.vargontoc.framework.ai.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Fragmento de una respuesta en streaming (formato OpenAI, {@code stream=true})
 *
 * @param choices choices del fragmento
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ChatCompletionChunk(List<Choice> choices) {

    /**
     * Texto incremental del fragmento
     *
     * @return texto, o cadena vacía si el fragmento no aporta contenido
     */
    public String contentOrEmpty() {
        if (choices == null || choices.isEmpty() || choices.get(0).delta() == null
                || choices.get(0).delta().content() == null) {
            return "";
        }
        return choices.get(0).delta().content();
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Choice(Delta delta) {
        @JsonIgnoreProperties(ignoreUnknown = true)
        public record Delta(String content) {
        }
    }
}
