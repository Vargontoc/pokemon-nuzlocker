package es.vargontoc.framework.ai.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Solicitud de completado de chat para la API de IA (formato OpenAI)
 *
 * @param model       modelo de IA a utilizar
 * @param messages    mensajes de chat
 * @param temperature temperatura de muestreo
 * @param stream      true para respuesta en streaming
 * @param maxTokens   máximo de tokens a generar
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ChatCompletionRequest(
        String model,
        List<ChatMessage> messages,
        Double temperature,
        Boolean stream,
        @JsonProperty("max_tokens") Integer maxTokens) {
}
