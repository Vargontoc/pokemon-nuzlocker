package es.vargontoc.framework.ai.model;

import java.util.List;

/**
 * Respuesta de completado de chat para la API de IA
 * 
 * @param model    modelo de IA a utilizar
 * @param messages mensajes de chat
 */
public record ChatCompletionResponse(String id, String model, List<Choice> choices, Usage usage) {

    /**
     * Contenido del primer choice
     *
     * @return texto de la respuesta, o cadena vacía si no hay
     */
    public String contentOrEmpty() {
        if (choices == null || choices.isEmpty() || choices.get(0).message() == null) {
            return "";
        }
        String content = choices.get(0).message().content();
        return content != null ? content : "";
    }

    /**
     * Choice de la respuesta de completado de chat para la API de IA
     * 
     * @param message       mensaje de chat
     * @param finish_reason razón de finalización
     * @param index         índice
     */
    public record Choice(Message message, String finish_reason, Integer index) {
        /**
         * Message de la respuesta de completado de chat para la API de IA
         * 
         * @param role    rol del mensaje
         * @param content contenido del mensaje
         */
        public record Message(String role, String content) {
        }
    }

    public record Usage(Integer prompt_tokens, Integer completion_tokens, Integer total_tokens) {
    }
}
