package es.vargontoc.framework.ai.model;

/**
 * Opciones por petición, independientes del backend (REST o Spring AI)
 *
 * @param temperature temperatura de muestreo, null para usar la del modelo
 * @param maxTokens   máximo de tokens a generar, null para usar el del modelo
 */
public record ChatOptions(Double temperature, Integer maxTokens) {

    private static final ChatOptions DEFAULTS = new ChatOptions(null, null);

    /**
     * Opciones por defecto: no sobrescribe nada del modelo
     *
     * @return opciones por defecto
     */
    public static ChatOptions defaults() {
        return DEFAULTS;
    }
}
