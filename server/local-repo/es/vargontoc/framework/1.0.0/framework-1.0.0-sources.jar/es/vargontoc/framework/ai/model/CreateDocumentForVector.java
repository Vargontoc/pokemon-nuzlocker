package es.vargontoc.framework.ai.model;

import java.util.Map;

public record CreateDocumentForVector(String id, String content, Map<String, Object> metadata) {
    
}
