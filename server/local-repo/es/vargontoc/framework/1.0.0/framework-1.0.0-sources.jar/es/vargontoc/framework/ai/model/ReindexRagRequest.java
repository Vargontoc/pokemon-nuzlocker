package es.vargontoc.framework.ai.model;

import java.util.Map;

public record ReindexRagRequest(
        String vectorName,
        String content,
        String id,
        Map<String,Object> metadata) {
    
}
