package es.vargontoc.framework.ai.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Filtro por metadatos para una búsqueda vectorial: todas las condiciones deben
 * cumplirse (AND). Es inmutable; cada método devuelve un filtro nuevo.
 * <pre>
 * VectorFilter.where().eq("source", "guide").gte("stepOrder", 3).lte("stepOrder", 6)
 * </pre>
 * Los valores pueden ser texto, números o booleanos.
 */
public final class VectorFilter {

    public enum Operator {
        EQ, NE, GT, GTE, LT, LTE
    }

    public record Condition(Operator operator, String key, Object value) {
    }

    private static final VectorFilter EMPTY = new VectorFilter(List.of());

    private final List<Condition> conditions;

    private VectorFilter(List<Condition> conditions) {
        this.conditions = conditions;
    }

    /** Filtro sin condiciones, punto de partida para encadenar */
    public static VectorFilter where() {
        return EMPTY;
    }

    public VectorFilter eq(String key, Object value) {
        return with(Operator.EQ, key, value);
    }

    public VectorFilter ne(String key, Object value) {
        return with(Operator.NE, key, value);
    }

    public VectorFilter gt(String key, Object value) {
        return with(Operator.GT, key, value);
    }

    public VectorFilter gte(String key, Object value) {
        return with(Operator.GTE, key, value);
    }

    public VectorFilter lt(String key, Object value) {
        return with(Operator.LT, key, value);
    }

    public VectorFilter lte(String key, Object value) {
        return with(Operator.LTE, key, value);
    }

    public List<Condition> conditions() {
        return conditions;
    }

    public boolean isEmpty() {
        return conditions.isEmpty();
    }

    private VectorFilter with(Operator operator, String key, Object value) {
        if (key == null || key.isBlank()) {
            throw new IllegalArgumentException("La clave del filtro no puede estar vacía");
        }
        if (!(value instanceof String || value instanceof Number || value instanceof Boolean)) {
            throw new IllegalArgumentException("El valor del filtro '" + key
                    + "' debe ser texto, número o booleano y es: " + value);
        }
        List<Condition> next = new ArrayList<>(conditions);
        next.add(new Condition(operator, key, value));
        return new VectorFilter(List.copyOf(next));
    }

    @Override
    public String toString() {
        return conditions.toString();
    }
}
