package es.vargontoc.framework.ai.model;

import java.util.Map;


/**
 * Documento devuelto por una búsqueda vectorial.
 *
 * @param id       id del documento
 * @param content  texto del documento
 * @param metadata metadatos con los que se guardó
 * @param score    similitud con la consulta (mayor es más parecido); puede ser null si el store no la informa
 */
public record VectorHit(String id, String content, Map<String, Object> metadata, Double score) {
}
