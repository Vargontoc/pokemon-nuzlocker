package es.vargontoc.framework.ai.model;

/**
 * Consulta a un VectorStore. Lo que sea {@code null} toma el valor de
 * {@code vector-store} del agente y, si tampoco lo define, el de Spring AI.
 *
 * @param text                texto a buscar
 * @param topK                máximo de resultados
 * @param similarityThreshold similitud mínima entre 0 y 1; {@code 0.0} acepta todo
 * @param filter              filtro por metadatos; null o vacío = sin filtro
 */
public record VectorQuery(String text, Integer topK, Double similarityThreshold, VectorFilter filter) {

    public VectorQuery {
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException("El texto de la consulta no puede estar vacío");
        }
        if (topK != null && topK <= 0) {
            throw new IllegalArgumentException("topK debe ser mayor que 0");
        }
        if (similarityThreshold != null && (similarityThreshold < 0 || similarityThreshold > 1)) {
            throw new IllegalArgumentException("similarityThreshold debe estar entre 0 y 1");
        }
    }

    public static VectorQuery of(String text) {
        return new VectorQuery(text, null, null, null);
    }

    public VectorQuery topK(int topK) {
        return new VectorQuery(text, topK, similarityThreshold, filter);
    }

    public VectorQuery similarityThreshold(double similarityThreshold) {
        return new VectorQuery(text, topK, similarityThreshold, filter);
    }

    public VectorQuery filter(VectorFilter filter) {
        return new VectorQuery(text, topK, similarityThreshold, filter);
    }
}
