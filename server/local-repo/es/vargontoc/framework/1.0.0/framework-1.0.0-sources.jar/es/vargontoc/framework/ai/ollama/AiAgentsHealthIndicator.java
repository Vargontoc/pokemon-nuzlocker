package es.vargontoc.framework.ai.ollama;

import java.util.List;

import org.jspecify.annotations.Nullable;
import org.springframework.boot.health.contributor.Health;
import org.springframework.boot.health.contributor.HealthIndicator;

import es.vargontoc.framework.ai.configuration.AiClientType;
import es.vargontoc.framework.ai.domain.DomainAgent;
import es.vargontoc.framework.ai.domain.DomainAgentRegistry;
import es.vargontoc.framework.ai.domain.ModelVerifier;

/**
 * HealthIndicator de los agentes de IA servidos por REST: DOWN si el proveedor
 * (Ollama) no responde o si algún modelo no está disponible. Los agentes de Spring AI no se comprueban.
 */
public class AiAgentsHealthIndicator implements HealthIndicator {

    private final ModelVerifier verifier;
    private final DomainAgentRegistry registry;

    /**
     * @param verifier verificador de modelos
     * @param registry registro de agentes
     */
    public AiAgentsHealthIndicator(ModelVerifier verifier, DomainAgentRegistry registry) {
        this.verifier = verifier;
        this.registry = registry;
    }

    @Override
    public @Nullable Health health() {
        List<DomainAgent> restAgents = registry.getAgents().stream()
                .filter(a -> a.getClientType() == AiClientType.REST).toList();
        if (restAgents.isEmpty()) {
            return Health.up().build();
        }
        if (!verifier.isReachable()) {
            return Health.down().withDetail("ollama", "no alcanzable").build();
        }

        List<String> unavailable = restAgents.stream()
                .filter(a -> !verifier.isModelAvailable(a.getModel()))
                .map(a -> a.getDomain() + " (" + a.getModel() + ")")
                .toList();

        if (unavailable.isEmpty()) {
            return Health.up().build();
        }
        return Health.down().withDetail("unavailableModels", unavailable).build();
    }
}
