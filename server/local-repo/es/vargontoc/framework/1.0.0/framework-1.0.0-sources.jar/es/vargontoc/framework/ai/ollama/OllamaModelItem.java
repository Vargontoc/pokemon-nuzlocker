package es.vargontoc.framework.ai.ollama;

/**
 * Item de modelo de Ollama
 * 
 * @param name  nombre del modelo
 * @param model tags/alias del modelo
 */
public record OllamaModelItem(String name, String model) {
}
