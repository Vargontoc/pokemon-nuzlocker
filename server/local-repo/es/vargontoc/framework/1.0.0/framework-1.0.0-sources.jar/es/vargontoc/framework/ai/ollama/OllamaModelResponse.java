package es.vargontoc.framework.ai.ollama;

import java.util.List;

/**
 * Respuesta de la API de Ollama con los modelos disponibles
 * 
 * @param models lista de modelos disponibles
 */
public record OllamaModelResponse(List<OllamaModelItem> models) {

}
