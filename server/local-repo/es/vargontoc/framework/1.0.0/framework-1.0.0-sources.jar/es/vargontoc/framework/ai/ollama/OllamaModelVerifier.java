package es.vargontoc.framework.ai.ollama;

import java.net.http.HttpClient;
import java.time.Duration;

import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import es.vargontoc.framework.ai.configuration.AiProperties;
import es.vargontoc.framework.ai.domain.ModelVerifier;

/**
 * Verificador de modelos de Ollama
 */
public class OllamaModelVerifier implements ModelVerifier {

    private static final String OPENAI_COMPAT_SUFFIX = "/v1";
    /** La comprobación no debe retrasar el arranque si el host no responde */
    private static final long MAX_TIMEOUT_MILLIS = 5000;

    private final RestClient client;

    public OllamaModelVerifier(AiProperties properties) {
        this(properties, RestClient.builder());
    }

    public OllamaModelVerifier(AiProperties properties, RestClient.Builder builder) {
        Duration timeout = Duration.ofMillis(Math.min(properties.timeout(), MAX_TIMEOUT_MILLIS));
        JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory(
                HttpClient.newBuilder().connectTimeout(timeout).build());
        factory.setReadTimeout(timeout);
        this.client = builder.clone()
                .baseUrl(ollamaRoot(properties.baseUrl()))
                .requestFactory(factory)
                .build();
    }

    /**
     * La base configurada apunta al endpoint compatible con OpenAI (.../v1), pero
     * el listado de modelos de Ollama vive en la raíz (/api/tags).
     */
    static String ollamaRoot(String baseUrl) {
        String root = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        return root.endsWith(OPENAI_COMPAT_SUFFIX)
                ? root.substring(0, root.length() - OPENAI_COMPAT_SUFFIX.length())
                : root;
    }

    @Override
    public boolean isReachable() {
        try {
            client.get().uri("/api/tags").retrieve().toBodilessEntity();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean isModelAvailable(String modelName) {
        try {
            OllamaModelResponse response = client.get().uri("/api/tags").retrieve().body(OllamaModelResponse.class);

            if (response == null || response.models() == null) {
                return false;
            }

            return response.models().stream().anyMatch(
                    m -> modelName.equalsIgnoreCase(m.name()) || (modelName + ":latest").equalsIgnoreCase(m.model())
                            || (modelName + ":latest").equalsIgnoreCase(m.name()));
        } catch (Exception e) {
            return false;
        }
    }
}
