package es.vargontoc.framework.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Configuración del filtro de request id
 * 
 * @param enabled    activa o desactiva el filtro
 * @param headerName cabecera HTTP de la que se lee y en la se devuelve request
 *                   id
 * @param mdcKey     clave del MDC donde se guarda el request id para los logs
 */
@ConfigurationProperties(prefix = "es.vargontoc.framework.request-id")
public record RequestIdProperties(
        @DefaultValue("true") boolean enabled,
        @DefaultValue("X-Request-Id") String headerName,
        @DefaultValue("requestId") String mdcKey) {
}
