package es.vargontoc.framework.exception;

import java.util.Collection;

import org.springframework.http.HttpStatus;

/**
 * El agente de IA solicitado no existe o está deshabilitado
 */
public class AgentNotFoundException extends AppException {

    public AgentNotFoundException(String domain, Collection<String> available) {
        super("El agente '" + domain + "' no existe o está deshabilitado. Disponibles: " + available,
                HttpStatus.NOT_FOUND);
    }
}
