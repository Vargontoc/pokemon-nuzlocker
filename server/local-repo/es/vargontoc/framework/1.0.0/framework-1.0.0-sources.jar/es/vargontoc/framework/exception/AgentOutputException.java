package es.vargontoc.framework.exception;

public class AgentOutputException extends Exception {
    private final String raw;

    public AgentOutputException(String raw, String message, Throwable e) {
        super(message, e);
        this.raw = raw;
    }

    public String getRaw() {
        return raw;
    }
}
