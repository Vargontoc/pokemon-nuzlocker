package es.vargontoc.framework.exception;

import org.springframework.http.HttpStatus;

/**
 * Clase base para excepciones de aplicacion
 */
public class AppException extends RuntimeException {

    private final HttpStatus status;

    public AppException(String message, HttpStatus status) {
        super(message);
        this.status = status;
    }

    /**
     * Obtiene el estado HTTP
     * 
     * @return Estado HTTP
     */
    public HttpStatus getStatus() {
        return status;
    }
}
