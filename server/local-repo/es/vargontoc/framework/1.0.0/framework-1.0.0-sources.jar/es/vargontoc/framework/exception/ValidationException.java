package es.vargontoc.framework.exception;

import org.springframework.http.HttpStatus;

/**
 * Excepcion que se lanza cuando ocurre un error de validacion
 */
public class ValidationException extends AppException {

    public ValidationException(String message) {
        super(message, HttpStatus.BAD_REQUEST);
    }
}
