package es.vargontoc.framework.mapper;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Clase base para mapear entidades a DTOs y viceversa
 * 
 * @param <T> tipo de la entidad
 * @param <D> tipo del DTO
 */
public abstract class BaseMapper<T, D> {

    /**
     * Método que convierte una entidad a DTO
     * 
     * @param entity entidad a convertir
     * @return DTO convertido
     */
    public abstract D toDto(T entity);

    /**
     * Método que convierte un DTO a entidad
     * 
     * @param dto DTO a convertir
     * @return entidad convertida
     */
    public abstract T toEntity(D dto);

    /**
     * Método que convierte una lista de entidades a una lista de DTOs
     * 
     * @param entities lista de entidades a convertir
     * @return lista de DTOs convertidos
     */
    public List<D> toDtoList(List<T> entities) {
        return entities.stream().map(this::toDto).collect(Collectors.toList());
    }

    /**
     * Método que convierte una lista de DTOs a una lista de entidades
     * 
     * @param dtos lista de DTOs a convertir
     * @return lista de entidades convertidas
     */
    public List<T> toEntityList(List<D> dtos) {
        return dtos.stream().map(this::toEntity).collect(Collectors.toList());
    }
}
