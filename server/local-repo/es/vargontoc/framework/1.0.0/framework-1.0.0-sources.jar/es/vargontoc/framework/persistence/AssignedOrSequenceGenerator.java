package es.vargontoc.framework.persistence;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.generator.EventType;
import org.hibernate.id.enhanced.SequenceStyleGenerator;

/**
 * Generador de ids de {@link BaseEntity}: usa el id que trae la entidad (p. ej. los de PokeAPI al importar
 * datos de referencia) y, si no trae, toma el siguiente valor de la secuencia.
 * <p>
 * Al permitir ids asignados, Hibernate ya no da por "detached" a toda entidad con id: comprueba en base de
 * datos si existe y, si no, la inserta con ese id en lugar de fallar con
 * {@code ObjectOptimisticLockingFailureException}.
 */
public class AssignedOrSequenceGenerator extends SequenceStyleGenerator {

    @Override
    public Object generate(SharedSessionContractImplementor session, Object owner, Object currentValue,
            EventType eventType) {
        return currentValue != null ? currentValue : super.generate(session, owner);
    }

    @Override
    public boolean allowAssignedIdentifiers() {
        return true;
    }
}
