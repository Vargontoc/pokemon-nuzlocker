package es.vargontoc.framework.persistence;

import java.util.List;
import java.util.Optional;

import es.vargontoc.framework.mapper.BaseMapper;

/**
 * Adaptador entre la persistencia y el resto de la aplicación: trabaja con DTOs y
 * convierte a entidad con el mapper. Se extiende (y se registra como bean) en el
 * consumidor para añadir sus consultas propias; recibe la interface de repositorio que
 * Spring Data implementa.
 * <pre>
 * interface PokemonRepository extends BaseRepository&lt;Long, PokemonEntity&gt; {}
 *
 * &#64;Component
 * class PokemonAdapter extends BaseAdapter&lt;Long, PokemonEntity, PokemonDto, PokemonMapper&gt; {
 *     PokemonAdapter(PokemonRepository repository, PokemonMapper mapper) { super(repository, mapper); }
 * }
 * </pre>
 *
 * @param <K> tipo de la clave
 * @param <T> tipo de la entidad
 * @param <D> tipo del DTO
 * @param <M> mapper entre entidad y DTO
 */
public abstract class BaseAdapter<K, T extends BaseEntity<K>, D, M extends BaseMapper<T, D>> {

    protected final BaseRepository<K, T> repository;
    protected final M mapper;

    protected BaseAdapter(BaseRepository<K, T> repository, M mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public Optional<D> findById(K id) {
        return repository.findById(id).map(mapper::toDto);
    }

    public List<D> findAll() {
        return mapper.toDtoList(repository.findAll());
    }

    /**
     * Crea el DTO como entidad nueva o actualiza la existente si trae id
     *
     * @return el DTO tal y como quedó guardado (con id y fechas)
     */
    public D save(D dto) {
        return mapper.toDto(repository.save(mapper.toEntity(dto)));
    }

    public List<D> saveAll(List<D> dtos) {
        return mapper.toDtoList(repository.saveAll(mapper.toEntityList(dtos)));
    }

    public boolean existsById(K id) {
        return repository.existsById(id);
    }

    public long count() {
        return repository.count();
    }

    public void deleteById(K id) {
        repository.deleteById(id);
    }
}
