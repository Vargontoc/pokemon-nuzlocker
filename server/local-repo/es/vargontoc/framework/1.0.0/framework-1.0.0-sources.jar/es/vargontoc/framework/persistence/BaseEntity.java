package es.vargontoc.framework.persistence;

import java.time.LocalDateTime;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;

/**
 * Entidad base para el proyecto
 * 
 * @param <K> tipo de la clave
 */
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class BaseEntity<K> {

    /**
     * Identificador único de la entidad: el que se asigne a mano o, si no hay, el siguiente de
     * {@code default_seq}
     */
    @Id
    @GeneratedValue(generator = "default_seq")
    @GenericGenerator(name = "default_seq", type = AssignedOrSequenceGenerator.class, parameters = {
            @Parameter(name = "sequence_name", value = "default_seq"),
            @Parameter(name = "increment_size", value = "50") })
    private K id;

    /**
     * Fecha de creación de la entidad
     */
    @CreatedDate
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Fecha de modificación de la entidad
     */
    @LastModifiedDate
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;

    /**
     * Método que devuelve el identificador único de la entidad
     * 
     * @return identificador único de la entidad
     */
    public K getId() {
        return id;
    }

    /**
     * Método que establece el identificador único de la entidad
     * 
     * @param id identificador único de la entidad
     */
    public void setId(K id) {
        this.id = id;
    }

    /**
     * Método que devuelve la fecha de creación de la entidad
     * 
     * @return fecha de creación de la entidad
     */
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    /**
     * Método que establece la fecha de creación de la entidad
     * 
     * @param createdAt fecha de creación de la entidad
     */
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Método que devuelve la fecha de modificación de la entidad
     * 
     * @return fecha de modificación de la entidad
     */
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Método que establece la fecha de modificación de la entidad
     * 
     * @param updatedAt fecha de modificación de la entidad
     */
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
