package es.vargontoc.framework.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

/**
 * Repositorio base: el consumidor declara una interface que lo extienda y Spring Data
 * genera la implementación. {@link BaseAdapter} lo usa para acceder a la base de datos.
 *
 * @param <K> tipo de la clave
 * @param <T> tipo de la entidad
 */
@NoRepositoryBean
public interface BaseRepository<K, T extends BaseEntity<K>> extends JpaRepository<T, K> {
}
