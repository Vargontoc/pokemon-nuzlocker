package es.vargontoc.framework.validation;

import es.vargontoc.framework.exception.ValidationException;

public abstract class AbstractValidator<T> implements Validator<T> {

    /**
     * Valida que el valor no sea nulo
     * 
     * @param value   Valor a validar
     * @param message Mensaje de error si el valor es nulo
     */
    protected void requiredNonNull(Object value, String message) {
        if (value == null)
            throw new ValidationException(message);
    }

    /**
     * Valida que el string no sea nulo ni este vacio
     * 
     * @param value   String a validar
     * @param message Mensaje de error si el string es nulo o esta vacio
     */
    protected void requiresNonBlank(String value, String message) {
        if (value == null || value.trim().isBlank())
            throw new ValidationException(message);
    }

    /**
     * Valida que la longitud maxima no sea superada
     * 
     * @param value   String a validar
     * @param max     Longitud maxima
     * @param message Mensaje de error si la longitud maxima es superada
     */
    protected void requiredMaxLength(String value, int max, String message) {
        if (value != null && value.length() > max)
            throw new ValidationException(message);
    }

    /**
     * Valida que la longitud del string este dentro de un rango
     * 
     * @param value   String a validar
     * @param min     Longitud minima
     * @param max     Longitud maxima
     * @param message Mensaje de error si la longitud del string esta fuera del
     *                rango
     */
    protected void requiredRangeLength(String value, int min, int max, String message) {
        if (value != null && (value.length() < min || value.length() > max))
            throw new ValidationException(message);
    }

    /**
     * Valida que el numero no sea nulo ni menor que cero
     * 
     * @param value   Numero a validar
     * @param message Mensaje de error si el numero es nulo o menor que cero
     */
    protected void requiredNonNegative(Number value, String message) {
        if (value == null || value.doubleValue() < 0)
            throw new ValidationException(message);
    }

    /**
     * Valida que el numero no sea nulo ni menor o igual a cero
     * 
     * @param value   Numero a validar
     * @param message Mensaje de error si el numero es nulo o menor o igual a cero
     */
    protected void requiredPositive(Number value, String message) {
        if (value == null || value.doubleValue() <= 0)
            throw new ValidationException(message);
    }

    /**
     * Valida que el numero este dentro de un rango
     * 
     * @param value   Numero a validar
     * @param min     Valor minimo
     * @param max     Valor maximo
     * @param message Mensaje de error si el numero esta fuera del rango
     */
    protected void requiredRangeNumber(Number value, Number min, Number max, String message) {
        if (value != null && (value.doubleValue() < min.doubleValue() || value.doubleValue() > max.doubleValue()))
            throw new ValidationException(message);
    }
}
