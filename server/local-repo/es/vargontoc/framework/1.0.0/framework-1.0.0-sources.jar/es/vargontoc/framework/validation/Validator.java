package es.vargontoc.framework.validation;

/**
 * Interfaz funcional para validaciones
 * 
 * @param <T> Tipo de objeto a validar
 * 
 */
@FunctionalInterface
public interface Validator<T> {

    /**
     * Valida un objeto
     * 
     * @param target Objeto a validar
     */
    void validate(T target);
}
