package es.vargontoc.framework.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.slf4j.Marker;
import org.slf4j.MarkerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.filter.OncePerRequestFilter;

import es.vargontoc.framework.exception.AppException;
import es.vargontoc.framework.web.models.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Clase base para los manejadores de excepciones globales
 * 
 */
@ControllerAdvice
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass(OncePerRequestFilter.class)
@ConditionalOnProperty(prefix = "es.vargontoc.framework.web.global-handler", name = "enabled", havingValue = "true", matchIfMissing = true)
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    private static final Marker EXCEPTION_MARKER = MarkerFactory.getMarker("EXCEPTION_MARKER");
    private static final String INTERNAL_ERROR_MESSAGE = "An unexpected error occurred";

    /**
     * Maneja las excepciones de aplicación (validación, recurso no encontrado...),
     * respondiendo con el estado HTTP que lleva la propia excepción
     *
     * @param exception excepción de aplicación
     * @param request   petición HTTP
     * @return respuesta con el estado y el mensaje de la excepción
     */
    @ExceptionHandler(AppException.class)
    public ResponseEntity<ApiResponse<Void>> handleAppException(
            AppException exception, HttpServletRequest request) {
        logDomainException(exception, request);
        return ResponseEntity
                .status(exception.getStatus())
                .body(ApiResponse.error(exception.getMessage()));
    }

    /**
     * Maneja las excepciones no controladas
     * 
     * @param exception excepción no controlada
     * @param request   petición HTTP
     * @return respuesta con error no controlado
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleUnhandledException(
            Exception exception, HttpServletRequest request) {
        putRequestContext(request, 500, exception.getClass().getSimpleName());
        LOGGER.error(EXCEPTION_MARKER, "Unhandled exception at {} {}", request.getMethod(), request.getRequestURI(),
                exception);
        MDC.clear();
        return ResponseEntity
                .internalServerError()
                .body(ApiResponse.error(INTERNAL_ERROR_MESSAGE));
    }

    private void logDomainException(AppException exception, HttpServletRequest request) {
        putRequestContext(request, exception.getStatus().value(), exception.getClass().getSimpleName());
        LOGGER.warn(EXCEPTION_MARKER, "Domain exception at {} {}: {}",
                request.getMethod(), request.getRequestURI(), exception.getMessage());
        MDC.clear();
    }

    private void putRequestContext(HttpServletRequest request, int httpStatus, String exceptionType) {
        MDC.put("requestUri", request.getRequestURI());
        MDC.put("requestMethod", request.getMethod());
        MDC.put("httpStatus", String.valueOf(httpStatus));
        MDC.put("exceptionType", exceptionType);
    }
}
