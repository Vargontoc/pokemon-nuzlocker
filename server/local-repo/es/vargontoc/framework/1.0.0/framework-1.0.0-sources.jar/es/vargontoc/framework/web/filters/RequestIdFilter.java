package es.vargontoc.framework.web.filters;

import java.io.IOException;
import java.util.UUID;
import java.util.regex.Pattern;

import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.web.filter.OncePerRequestFilter;

import es.vargontoc.framework.configuration.RequestIdProperties;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class RequestIdFilter extends OncePerRequestFilter implements Ordered {
    private static final Pattern VALID_REQUEST_ID = Pattern.compile("[A-Za-z0-9._-]{1,64}");
    private final RequestIdProperties properties;

    public RequestIdFilter(RequestIdProperties properties) {
        this.properties = properties;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String requestId = resolveRequestId(request);

        MDC.put(properties.mdcKey(), requestId);
        response.setHeader(properties.headerName(), requestId);
        try {
            filterChain.doFilter(request, response);
        } finally {
            MDC.remove(properties.mdcKey());
        }
    }

    private String resolveRequestId(HttpServletRequest request) {
        String incoming = request.getHeader(properties.headerName());
        if (incoming != null && !incoming.isBlank() && VALID_REQUEST_ID.matcher(incoming).matches()) {
            return incoming;
        }
        return UUID.randomUUID().toString();
    }

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE + 10;
    }

}
