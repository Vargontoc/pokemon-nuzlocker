package es.vargontoc.framework.web.models;

import java.util.List;

/**
 * Clase base para las respuestas de la API
 * 
 * @param <T> tipo de los datos
 */
public record ApiResponse<T>(
        boolean success,
        String message,
        List<String> errors,
        T data) {

    /**
     * Método que crea una respuesta exitosa
     * 
     * @param data datos a devolver
     * @return respuesta exitosa
     */
    public static <T> ApiResponse<T> ok(T data) {
        return new ApiResponse<>(true, null, null, data);
    }

    /**
     * Método que crea una respuesta exitosa
     * 
     * @param message mensaje exitoso
     * @return respuesta exitosa
     */
    public static <T> ApiResponse<T> ok(String message) {
        return new ApiResponse<>(true, message, null, null);
    }

    /**
     * Método que crea una respuesta de error
     * 
     * @param message mensaje de error
     * @return respuesta de error
     */
    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(false, message, null, null);
    }

    /**
     * Método que crea una respuesta de error con errores
     * 
     * @param message mensaje de error
     * @param errors  lista de errores
     * @return respuesta de error
     */
    public static <T> ApiResponse<T> error(String message, List<String> errors) {
        return new ApiResponse<>(false, message, errors, null);
    }
}
