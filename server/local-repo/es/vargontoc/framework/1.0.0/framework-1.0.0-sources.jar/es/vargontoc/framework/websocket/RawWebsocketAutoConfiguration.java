package es.vargontoc.framework.websocket;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
import org.springframework.web.socket.server.HandshakeInterceptor;

import es.vargontoc.framework.websocket.configuration.WebsocketProperties;
import es.vargontoc.framework.websocket.raw.AbstractWebsocketHandler;
import es.vargontoc.framework.websocket.raw.HandlerRawWebsocketEventPublisher;
import es.vargontoc.framework.websocket.raw.RawWebsocketEventPublisher;

/**
 * Websocket "normal" (sin STOMP): registra cada {@link AbstractWebsocketHandler}
 * declarado como bean por el proyecto consumidor en su {@code endpoint()}.
 * Solo se activa si existe al menos uno. Convive con el broker STOMP.
 */
@AutoConfiguration
@EnableWebSocket
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass(WebSocketConfigurer.class)
@ConditionalOnBean(AbstractWebsocketHandler.class)
@EnableConfigurationProperties(WebsocketProperties.class)
@ConditionalOnProperty(prefix = "es.vargontoc.framework.websocket", name = "enabled", havingValue = "true", matchIfMissing = true)
public class RawWebsocketAutoConfiguration implements WebSocketConfigurer {

    private final ObjectProvider<AbstractWebsocketHandler> handlers;
    private final WebsocketProperties properties;

    public RawWebsocketAutoConfiguration(ObjectProvider<AbstractWebsocketHandler> handlers,
            WebsocketProperties properties) {
        this.handlers = handlers;
        this.properties = properties;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        Set<String> endpoints = new HashSet<>();
        handlers.orderedStream().forEach(handler -> {
            if (!endpoints.add(handler.endpoint())) {
                throw new IllegalStateException(
                        "Hay más de un AbstractWebsocketHandler en el endpoint '" + handler.endpoint() + "'");
            }
            registry.addHandler(handler, handler.endpoint())
                    .setAllowedOriginPatterns(properties.allowOrigins())
                    .addInterceptors(handler.handshakeInterceptors().toArray(new HandshakeInterceptor[0]));
        });
    }

    @Bean
    @ConditionalOnMissingBean
    public RawWebsocketEventPublisher rawWebsocketEventPublisher(ObjectProvider<AbstractWebsocketHandler> handlers) {
        return new HandlerRawWebsocketEventPublisher(handlers);
    }
}
