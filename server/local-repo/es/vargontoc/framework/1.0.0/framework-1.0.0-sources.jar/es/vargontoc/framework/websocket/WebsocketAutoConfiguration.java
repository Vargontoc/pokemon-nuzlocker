package es.vargontoc.framework.websocket;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

import es.vargontoc.framework.websocket.configuration.WebsocketProperties;
import es.vargontoc.framework.websocket.publisher.StompWebsocketEventPublisher;
import es.vargontoc.framework.websocket.publisher.WebsocketEventPublisher;

@AutoConfiguration
@EnableWebSocketMessageBroker
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass(WebSocketMessageBrokerConfigurer.class)
@EnableConfigurationProperties(WebsocketProperties.class)
@ConditionalOnProperty(prefix = "es.vargontoc.framework.websocket", name = "enabled", havingValue = "true", matchIfMissing = true)
public class WebsocketAutoConfiguration implements WebSocketMessageBrokerConfigurer {

    private final WebsocketProperties properties;

    public WebsocketAutoConfiguration(WebsocketProperties properties) {
        this.properties = properties;
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {

        // Los mensajes de usuario (/user/{nombre}/queue/x) se reescriben a {queuePrefix}/x-user{sesión},
        // por eso el broker debe atender queuePrefix y no userPrefix
        registry.enableSimpleBroker(properties.topicPrefix(), properties.queuePrefix());
        registry.setApplicationDestinationPrefixes(properties.appPrefix());
        registry.setUserDestinationPrefix(properties.userPrefix());
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        var endpoint = registry.addEndpoint(properties.endpoint()).setAllowedOriginPatterns(properties.allowOrigins());
        if (properties.enableSocket()) {
            endpoint.withSockJS();
        }
    }

    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {

    }

    @Bean
    @ConditionalOnMissingBean
    public WebsocketEventPublisher eventPublisher(SimpMessagingTemplate template) {
        return new StompWebsocketEventPublisher(template);
    }
}
