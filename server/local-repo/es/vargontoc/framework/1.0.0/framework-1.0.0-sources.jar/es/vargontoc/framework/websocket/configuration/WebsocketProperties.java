package es.vargontoc.framework.websocket.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Configuración del websocket (STOMP)
 * 
 * @param enabled      activa o desactiva el módulo
 * @param endpoint     ruta de conexión de los clientes
 * @param topicPrefix  prefijo de los destinos de difusión (broker)
 * @param queuePrefix  prefijo de los destinos punto a punto (broker); es donde se
 *                     entregan los mensajes dirigidos a un usuario
 * @param userPrefix   prefijo con el que los clientes se suscriben a sus destinos
 *                     de usuario (p. ej. {@code /user/queue/avisos})
 * @param appPrefix    prefijo de los destinos que atienden los controladores
 * @param allowOrigins orígenes permitidos (patrones)
 * @param enableSocket habilita el fallback SockJS en el endpoint
 */
@ConfigurationProperties(prefix = "es.vargontoc.framework.websocket")
public record WebsocketProperties(
        @DefaultValue("true") boolean enabled,
        @DefaultValue("/ws") String endpoint,
        @DefaultValue("/topic") String topicPrefix,
        @DefaultValue("/queue") String queuePrefix,
        @DefaultValue("/user") String userPrefix,
        @DefaultValue("/app") String appPrefix,
        @DefaultValue("*") String allowOrigins,
        @DefaultValue("false") boolean enableSocket) {

}
