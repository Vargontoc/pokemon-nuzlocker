package es.vargontoc.framework.websocket.model;

/**
 * Fragmento de una respuesta enviada en streaming por websocket
 * 
 * @param chunk texto del fragmento
 * @param last  true si es el último fragmento
 */
public record StreamChunk(String chunk, boolean last) {
}
