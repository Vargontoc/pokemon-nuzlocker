package es.vargontoc.framework.websocket.publisher;

import org.springframework.messaging.simp.SimpMessagingTemplate;

import es.vargontoc.framework.websocket.model.StreamChunk;

public class StompWebsocketEventPublisher implements WebsocketEventPublisher {

    private final SimpMessagingTemplate template;

    public StompWebsocketEventPublisher(SimpMessagingTemplate template) {
        this.template = template;
    }

    @Override
    public void sendTopic(String destination, Object payload) {
        template.convertAndSend(destination, payload);
    }

    @Override
    public void sendToUser(String username, String destination, Object payload) {
        template.convertAndSendToUser(username, destination, payload);
    }

    @Override
    public void sendStreamChunk(String destination, String chunk, boolean isLast) {
        template.convertAndSend(destination, new StreamChunk(chunk, isLast));
    }

}
