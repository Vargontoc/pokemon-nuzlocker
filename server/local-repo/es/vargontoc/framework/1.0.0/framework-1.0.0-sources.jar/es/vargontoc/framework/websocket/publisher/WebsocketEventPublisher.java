package es.vargontoc.framework.websocket.publisher;

public interface WebsocketEventPublisher {

    void sendTopic(String destination, Object payload);

    void sendToUser(String username, String destination, Object payload);

    void sendStreamChunk(String destination, String chunk, boolean isLast);
}
