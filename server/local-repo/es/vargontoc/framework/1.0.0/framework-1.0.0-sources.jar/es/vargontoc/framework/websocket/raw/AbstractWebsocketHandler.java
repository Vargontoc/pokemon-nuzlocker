package es.vargontoc.framework.websocket.raw;

import java.io.IOException;
import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.ConcurrentWebSocketSessionDecorator;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;

import tools.jackson.databind.json.JsonMapper;

/**
 * Base para un websocket "normal" (sin STOMP ni suscripciones) de texto.
 * <p>
 * El proyecto consumidor extiende esta clase, la declara como bean y la librería
 * la registra en {@link #endpoint()}. La clase mantiene las sesiones conectadas y
 * ofrece el envío (a una sesión, a un usuario o a todos) con serialización JSON.
 * El envío es seguro entre hilos.
 */
public abstract class AbstractWebsocketHandler extends TextWebSocketHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractWebsocketHandler.class);
    private static final int SEND_TIME_LIMIT_MILLIS = 10_000;
    private static final int SEND_BUFFER_LIMIT_BYTES = 512 * 1024;

    private final Map<String, WebSocketSession> sessions = new ConcurrentHashMap<>();
    private final JsonMapper mapper = JsonMapper.builder().build();

    /**
     * Ruta en la que se registra el handler
     *
     * @return ruta, por ejemplo {@code /ws/chat}
     */
    public abstract String endpoint();

    /**
     * Se invoca al recibir un mensaje de texto de un cliente
     *
     * @param session sesión del cliente (se puede responder con {@link #send})
     * @param payload contenido del mensaje
     * @throws Exception cualquier error; cierra la sesión con error de servidor
     */
    protected abstract void onMessage(WebSocketSession session, String payload) throws Exception;

    /**
     * Se invoca cuando un cliente se conecta
     *
     * @param session sesión del cliente
     */
    protected void onConnect(WebSocketSession session) {
    }

    /**
     * Se invoca cuando un cliente se desconecta
     *
     * @param session sesión del cliente
     * @param status  motivo del cierre
     */
    protected void onDisconnect(WebSocketSession session, CloseStatus status) {
    }

    /**
     * Usuario al que pertenece la sesión, usado por {@link #sendToUser}. Por defecto
     * es el nombre del {@link Principal} de la sesión; se sobrescribe si el proyecto
     * autentica de otra forma (por ejemplo con un token guardado en los atributos
     * por un {@link #handshakeInterceptors()}).
     *
     * @param session sesión del cliente
     * @return nombre de usuario, o null si es anónima
     */
    protected String username(WebSocketSession session) {
        Principal principal = session.getPrincipal();
        return principal != null ? principal.getName() : null;
    }

    /**
     * Interceptores del handshake (autenticación, validación de cabeceras...)
     *
     * @return interceptores a aplicar en {@link #endpoint()}
     */
    public List<HandshakeInterceptor> handshakeInterceptors() {
        return List.of();
    }

    /**
     * Envía un mensaje a todas las sesiones conectadas
     *
     * @param payload texto o un objeto que se serializa a JSON
     */
    public void broadcast(Object payload) {
        TextMessage message = new TextMessage(serialize(payload));
        sessions.values().forEach(session -> deliver(session, message));
    }

    /**
     * Envía un mensaje a una sesión
     *
     * @param sessionId identificador de la sesión
     * @param payload   texto o un objeto que se serializa a JSON
     */
    public void sendToSession(String sessionId, Object payload) {
        WebSocketSession session = sessions.get(sessionId);
        if (session == null) {
            LOGGER.debug("Sesión websocket {} no encontrada en {}", sessionId, endpoint());
            return;
        }
        deliver(session, new TextMessage(serialize(payload)));
    }

    /**
     * Envía un mensaje a todas las sesiones de un usuario
     *
     * @param username nombre de usuario (ver {@link #username})
     * @param payload  texto o un objeto que se serializa a JSON
     */
    public void sendToUser(String username, Object payload) {
        TextMessage message = new TextMessage(serialize(payload));
        sessions.values().stream().filter(session -> username.equals(username(session)))
                .forEach(session -> deliver(session, message));
    }

    /**
     * Responde a una sesión (por ejemplo desde {@link #onMessage})
     *
     * @param session sesión del cliente
     * @param payload texto o un objeto que se serializa a JSON
     */
    protected void send(WebSocketSession session, Object payload) {
        deliver(session, new TextMessage(serialize(payload)));
    }

    /**
     * Convierte el payload a texto: los textos se envían tal cual y el resto como JSON
     *
     * @param payload contenido a enviar
     * @return texto a enviar
     */
    protected String serialize(Object payload) {
        return payload instanceof CharSequence ? payload.toString() : mapper.writeValueAsString(payload);
    }

    private void deliver(WebSocketSession session, TextMessage message) {
        try {
            session.sendMessage(message);
        } catch (IOException | IllegalStateException e) {
            // Un cliente caído no debe impedir el envío al resto; su cierre lo limpia de la lista
            LOGGER.warn("No se pudo enviar al websocket {} de {}: {}", session.getId(), endpoint(), e.toString());
        }
    }

    @Override
    public final void afterConnectionEstablished(WebSocketSession session) {
        WebSocketSession safe = new ConcurrentWebSocketSessionDecorator(session, SEND_TIME_LIMIT_MILLIS,
                SEND_BUFFER_LIMIT_BYTES);
        sessions.put(session.getId(), safe);
        onConnect(safe);
    }

    @Override
    protected final void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        onMessage(sessions.getOrDefault(session.getId(), session), message.getPayload());
    }

    @Override
    public final void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        WebSocketSession safe = sessions.remove(session.getId());
        onDisconnect(safe != null ? safe : session, status);
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) {
        LOGGER.warn("Error de transporte en el websocket {} de {}: {}", session.getId(), endpoint(),
                exception.toString());
    }
}
