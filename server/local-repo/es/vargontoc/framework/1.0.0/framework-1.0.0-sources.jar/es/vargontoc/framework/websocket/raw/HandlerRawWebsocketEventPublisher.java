package es.vargontoc.framework.websocket.raw;

import org.springframework.beans.factory.ObjectProvider;

import es.vargontoc.framework.websocket.model.StreamChunk;

/**
 * Publicador que delega en el {@link AbstractWebsocketHandler} de cada endpoint.
 * Los handlers se buscan al enviar (no al construirse) para que un handler pueda
 * inyectar este publisher sin crear una dependencia circular.
 */
public class HandlerRawWebsocketEventPublisher implements RawWebsocketEventPublisher {

    private final ObjectProvider<AbstractWebsocketHandler> handlers;

    public HandlerRawWebsocketEventPublisher(ObjectProvider<AbstractWebsocketHandler> handlers) {
        this.handlers = handlers;
    }

    @Override
    public void broadcast(String endpoint, Object payload) {
        handler(endpoint).broadcast(payload);
    }

    @Override
    public void sendToSession(String endpoint, String sessionId, Object payload) {
        handler(endpoint).sendToSession(sessionId, payload);
    }

    @Override
    public void sendToUser(String endpoint, String username, Object payload) {
        handler(endpoint).sendToUser(username, payload);
    }

    @Override
    public void sendStreamChunk(String endpoint, String sessionId, String chunk, boolean isLast) {
        handler(endpoint).sendToSession(sessionId, new StreamChunk(chunk, isLast));
    }

    private AbstractWebsocketHandler handler(String endpoint) {
        return handlers.stream().filter(h -> h.endpoint().equals(endpoint)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No hay ningún websocket registrado en '" + endpoint
                        + "'. Disponibles: " + handlers.stream().map(AbstractWebsocketHandler::endpoint).toList()));
    }
}
