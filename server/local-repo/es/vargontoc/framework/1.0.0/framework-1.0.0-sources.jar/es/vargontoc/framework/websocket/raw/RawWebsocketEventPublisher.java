package es.vargontoc.framework.websocket.raw;

/**
 * Publicador para websockets "normales" (sin STOMP ni suscripciones): envía a las
 * sesiones conectadas a un {@link AbstractWebsocketHandler}, identificado por su
 * {@link AbstractWebsocketHandler#endpoint() endpoint}.
 * <p>
 * Los textos se envían tal cual y los objetos se serializan a JSON.
 */
public interface RawWebsocketEventPublisher {

    /**
     * Envía a todas las sesiones conectadas al endpoint
     *
     * @param endpoint ruta del handler
     * @param payload  texto u objeto (JSON)
     */
    void broadcast(String endpoint, Object payload);

    /**
     * Envía a una sesión concreta
     *
     * @param endpoint  ruta del handler
     * @param sessionId identificador de la sesión
     * @param payload   texto u objeto (JSON)
     */
    void sendToSession(String endpoint, String sessionId, Object payload);

    /**
     * Envía a todas las sesiones de un usuario
     *
     * @param endpoint ruta del handler
     * @param username usuario, según {@code AbstractWebsocketHandler#username}
     * @param payload  texto u objeto (JSON)
     */
    void sendToUser(String endpoint, String username, Object payload);

    /**
     * Envía a una sesión un fragmento de una respuesta larga, con la forma
     * {@code {"chunk":"...","last":false}}
     *
     * @param endpoint  ruta del handler
     * @param sessionId identificador de la sesión
     * @param chunk     texto del fragmento
     * @param isLast    true si es el último
     */
    void sendStreamChunk(String endpoint, String sessionId, String chunk, boolean isLast);
}
